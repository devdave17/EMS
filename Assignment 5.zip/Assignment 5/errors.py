"""Common public error format for the EMS Online Examination REST API."""
from dataclasses import dataclass


@dataclass
class ApiError(Exception):
    status: int
    title: str
    detail: str
    slug: str
    headers: tuple[tuple[str, str], ...] = ()


def problem(error: ApiError) -> dict[str, object]:
    return {
        "type": f"https://ems.example/problems/{error.slug}",
        "title": error.title,
        "status": error.status,
        "detail": error.detail,
    }
