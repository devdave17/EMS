"""Local test doubles for the EMS Authentication and Exam Schedule services.

This is only a local test helper; it is not part of the Online Examination
Service and does not claim to be a live EMS deployment.
"""
from __future__ import annotations

import argparse
import json
import threading
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

DEFAULT_EXAM = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
FUTURE_EXAM = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"
RETRY_ONCE_EXAM = "cccccccc-cccc-4ccc-8ccc-cccccccccccc"
CLOSED_EXAM = "dddddddd-dddd-4ddd-8ddd-dddddddddddd"
UNKNOWN_EXAM = "ffffffff-ffff-4fff-8fff-ffffffffffff"

COUNTS: dict[str, int] = {}
AUTH_KEYS: list[str] = []
AUTH_TOKEN_COUNTS: dict[str, int] = {}
LOCK = threading.Lock()


def json_bytes(payload: dict) -> bytes:
    return json.dumps(payload, separators=(",", ":")).encode("utf-8")


def schedule_for(exam_id: str) -> dict | None:
    now = datetime.now(timezone.utc)
    if exam_id == UNKNOWN_EXAM:
        return None
    status = "closed" if exam_id == CLOSED_EXAM else "scheduled"
    start = now + timedelta(hours=1) if exam_id == FUTURE_EXAM else now - timedelta(hours=1)
    end = now + timedelta(hours=2) if exam_id == FUTURE_EXAM else now + timedelta(hours=1)
    return {
        "exam_id": exam_id,
        "status": status,
        "start_at": start.isoformat().replace("+00:00", "Z"),
        "end_at": end.isoformat().replace("+00:00", "Z"),
        "duration_minutes": 120,
    }


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "EMS-Test-Dependency/1.0"
    sys_version = ""

    def log_message(self, *_args) -> None:
        pass

    def _send(self, status: int, payload: dict) -> None:
        body = json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        with LOCK:
            COUNTS[path] = COUNTS.get(path, 0) + 1
            count = COUNTS[path]
        if path == "/health":
            self._send(200, {"status": "ok"})
            return
        if path.startswith("/exams/"):
            exam_id = path.rsplit("/", 1)[-1]
            if exam_id == RETRY_ONCE_EXAM and count == 1:
                self._send(503, {"error": "temporary dependency failure"})
                return
            payload = schedule_for(exam_id)
            if payload is None:
                self._send(404, {"error": "exam not found"})
            else:
                self._send(200, payload)
            return
        self._send(404, {"error": "not found"})

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length", "0") or "0")
        try:
            body = json.loads(self.rfile.read(length).decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            self._send(400, {"error": "invalid JSON"})
            return
        if path == "/token-verifications":
            with LOCK:
                COUNTS[path] = COUNTS.get(path, 0) + 1
                AUTH_KEYS.append(self.headers.get("Idempotency-Key", ""))
            token = body.get("token") if isinstance(body, dict) else None
            with LOCK:
                AUTH_TOKEN_COUNTS[token or ""] = AUTH_TOKEN_COUNTS.get(token or "", 0) + 1
                token_count = AUTH_TOKEN_COUNTS[token or ""]
            # Used by tests to prove that a POST retry reuses its idempotency key.
            if token == "retry-auth-token" and token_count == 1:
                self._send(503, {"error": "temporary authentication failure"})
                return
            principals = {
                "student-token": {"user_id": "11111111-1111-4111-8111-111111111111", "roles": ["student"]},
                "proctor-token": {"user_id": "22222222-2222-4222-8222-222222222222", "roles": ["proctor"]},
                "admin-token": {"user_id": "33333333-3333-4333-8333-333333333333", "roles": ["admin"]},
                "authority-token": {"user_id": "44444444-4444-4444-8444-444444444444", "roles": ["exam_authority"]},
                "retry-auth-token": {"user_id": "11111111-1111-4111-8111-111111111111", "roles": ["student"]},
            }
            if token not in principals:
                self._send(401, {"valid": False, "error": "invalid token"})
            else:
                self._send(200, {"valid": True, **principals[token]})
            return
        self._send(404, {"error": "not found"})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8101, type=int)
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"EMS dependency mocks listening on http://{args.host}:{args.port}")
    print("This is a local test double, not a live EMS dependency.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
