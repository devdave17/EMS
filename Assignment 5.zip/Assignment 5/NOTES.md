# CS543 Web Services — Assignment 5: HTTP Methods & Headers

**Project:** Exam Management System (EMS)  
**Service:** Online Examination Service  
**Team ID:** 18  
**Name(s):** [Dev Dave, Arjun Bodana, Vikash Kumar, Kuldeep Rout]  
**Roll number(s):** [20251651034, 20251651029, 20251651102, 20251651053]

> The service owns `exam_sessions` and `session_timers`. Authentication and exam schedules are reached through HTTP contracts. The service does not read another service's store.

## Part A — Methods and the message

### A1. EMS method map

| Action | Method + URL | Success | Why this method fits |
|---|---|---|---|
| Start an exam session | `POST /exam-sessions` | `201 Created` + `Location` | Creates a new session resource. Requires `Idempotency-Key`. |
| Read one session | `GET /exam-sessions/{session_id}` | `200 OK`; `304` if ETag still matches | Reads a single resource and does not change it. |
| Search sessions | `GET /exam-sessions?exam_id=...&status=...&sort=...&limit=...&offset=...` | `200 OK` | Filtering, sorting and paging are query parameters; this stays a read. |
| Terminate a session | `POST /exam-sessions/{session_id}/termination` | `200 OK` | Termination is a state-changing action, so it is a POST to a noun sub-resource instead of `/terminateSession`. |
| Read the timer | `GET /exam-sessions/{session_id}/timer` | `200 OK`; `304` if unchanged | Reads a timer resource and returns an ETag. |
| Replace timer settings | `PUT /exam-sessions/{session_id}/timer` | `200 OK`; `412` if stale ETag | Replaces the writable timer values and requires `If-Match`. |
| Method-override fallback | `POST /exam-sessions/{session_id}/timer` with `X-HTTP-Method-Override: PUT` | Same as PUT | Only for a client that cannot send PUT. The server processes it as PUT. |
| Discover allowed methods / CORS preflight | `OPTIONS` on the resource URL | `204 No Content` | Returns `Allow`; for a valid browser preflight it also returns the CORS headers. |

There is no DELETE endpoint. An exam session is an examination record, so this service terminates it instead of deleting the record and losing its history. `OPTIONS` is supported on the resource URLs and `Allow` lists the accepted methods.

### A2. Non-CRUD action

We used `POST /exam-sessions/{session_id}/termination` for termination. We rejected `/terminateSession` because it puts an action in the URL. The session remains stored for examination history, but its state changes to `terminated`. If the same termination request is repeated, it returns the same final state instead of applying a second change.

### A3. Safe and idempotent behaviour

| Endpoint | Safe? | Idempotent? | Retry note |
|---|---|---|---|
| `POST /exam-sessions` | No | Not by default | `Idempotency-Key` makes a repeated create return the original session instead of creating another one. |
| `GET /exam-sessions/{session_id}` | Yes | Yes | It only reads; `If-None-Match` can save sending the body again. |
| `GET /exam-sessions?...` | Yes | Yes | Query filters and pagination only affect which records are returned. |
| `POST /exam-sessions/{session_id}/termination` | No | Yes in its state effect | Once terminated, repeating the same action leaves the resource terminated and returns the same representation. |
| `GET /exam-sessions/{session_id}/timer` | Yes | Yes | It only reads; it supports `If-None-Match`. |
| `PUT /exam-sessions/{session_id}/timer` | No | Yes for the replacement operation | It sets the timer values. `If-Match` stops a stale client overwriting a newer update; a retry with an old ETag gets 412 and must reread. |
| `OPTIONS` | Yes | Yes | It describes methods/headers without changing a session. |

The request that is neither safe nor naturally idempotent is `POST /exam-sessions`: each successful call would normally create a second session. The service stores the result associated with the authenticated user and `Idempotency-Key`. When the same key and body are sent again, it returns the original response and `Location`. Reusing the same key with a different body returns `409 Conflict`.

### A4. Query parameters

The session-list endpoint accepts `exam_id`, `status`, `sort`, `limit` and `offset`. The default sort is newest first (`sort=-started_at`), `limit` is from 1 to 100, and `offset` cannot be negative. The list response is `Cache-Control: no-store` because it contains private examination activity.

### A5. OPTIONS and method override

Example response to `OPTIONS /exam-sessions/{session_id}/timer`:

```http
HTTP/1.1 204 No Content
Allow: GET, PUT, POST, OPTIONS
Access-Control-Allow-Origin: http://localhost:5173
Access-Control-Allow-Methods: GET, PUT, POST, OPTIONS
Access-Control-Allow-Headers: authorization, content-type, if-match, x-http-method-override
Access-Control-Expose-Headers: ETag, Location, X-RateLimit-Limit, X-RateLimit-Remaining, Retry-After
```

The POST in `Allow` is only a documented fallback for a client that cannot send PUT. That client sends `POST /exam-sessions/{id}/timer` with `X-HTTP-Method-Override: PUT`, the normal JSON body, and the same `If-Match` header. The normal method remains PUT.

### A6. One complete HTTP exchange

This complete exchange was captured from the local demonstration run and is also in `curl-transcript.txt`.

**Request**

```http
POST /exam-sessions HTTP/1.1
Host: 127.0.0.1:18000
User-Agent: curl/8.10.1
Authorization: Bearer student-token
Accept: application/json
Content-Type: application/json
Idempotency-Key: ems-assignment5-create-001
Content-Length: 50

{"exam_id":"aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"}
```

**Response**

```http
HTTP/1.0 201 Created
Date: Tue, 13 Oct 2026 05:44:33 GMT
Server: WSGIServer/0.2 CPython/3.13.5
Content-Type: application/json; charset=utf-8
Cache-Control: no-store
Location: /exam-sessions/c3ae72f6-9aba-4ad0-b8ab-09bc086db9b0
ETag: "sha256-0fea35756f7d955a2f08c4c054e7eada86752a1261f43fd976dc6dbf67776b08"
X-Content-Type-Options: nosniff
Strict-Transport-Security: max-age=31536000; includeSubDomains
X-RateLimit-Limit: 120
X-RateLimit-Remaining: 118
Content-Length: 370

{"session_id":"c3ae72f6-9aba-4ad0-b8ab-09bc086db9b0","exam_id":"aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa","session_status":"active","started_at":"2026-10-13T05:44:33Z","expires_at":"2026-10-13T06:44:33Z","submitted_at":null,"timer":{"started_at":"2026-10-13T05:44:33Z","duration_seconds":3599,"remaining_seconds":3599,"paused_seconds":0,"updated_at":"2026-10-13T05:44:33Z"}}
```

The request uses HTTP/1.1. This Python WSGI demonstration replies with HTTP/1.0; its `Date` and `Server` headers are supplied by the local server, not hard-coded in the API code. The resource ID and ETag are the exact values from this recorded run; a new run will create a different session ID.

## Part B — Headers on messages

### Headers table

| Endpoint | Important request headers | Important response headers | Reason |
|---|---|---|---|
| `POST /exam-sessions` | `Authorization`, `Accept`, `Content-Type`, `Idempotency-Key` | `Location`, `ETag`, `Cache-Control: no-store`, `Content-Type` | Identifies the caller, states JSON format, and makes session creation retry-safe. |
| `GET /exam-sessions/{session_id}` | `Authorization`, `Accept`, optional `If-None-Match` | `ETag`, `Cache-Control: private, max-age=5, must-revalidate` | Allows a private cache to store the representation, but it must revalidate before reuse. |
| `GET /exam-sessions?...` | `Authorization`, `Accept` | `Cache-Control: no-store`, rate-limit headers | Session lists contain private examination activity and should not be stored by caches. |
| `POST /exam-sessions/{id}/termination` | `Authorization`, `Accept`, `Content-Type` | `Content-Type`, `Cache-Control: no-store`, `ETag` | A state-changing staff action; do not cache the response. |
| `GET /exam-sessions/{id}/timer` | `Authorization`, `Accept`, optional `If-None-Match` | `ETag`, `Cache-Control: private, max-age=0, must-revalidate` | Enables conditional reads of timer state. |
| `PUT /exam-sessions/{id}/timer` | `Authorization`, `Accept`, `Content-Type`, required `If-Match` | New `ETag`, `Cache-Control: private, no-cache` | Prevents a stale update from overwriting a newer timer. |
| `OPTIONS` | `Origin`, `Access-Control-Request-Method`, `Access-Control-Request-Headers` when preflighted | `Allow`, `Access-Control-Allow-Origin`, `Access-Control-Allow-Methods`, `Access-Control-Allow-Headers`, `Access-Control-Expose-Headers`, `Vary` | Lets a client/browser discover allowed methods and satisfy CORS preflight. |

### Content type and security

JSON request bodies must use `Content-Type: application/json`. Responses are JSON, and `Accept` is checked; requesting an unsupported type such as `text/html` returns `406 Not Acceptable`. Larger JSON responses are gzip-compressed when the request includes `Accept-Encoding: gzip`; the response then includes `Content-Encoding: gzip` and `Vary: Accept-Encoding`.

Protected operations require `Authorization: Bearer <token>`. Missing or empty bearer tokens return `401 Unauthorized`; this assignment checks the header shape and delegates token verification to the existing Authentication Service contract.

Every response includes `X-Content-Type-Options: nosniff` and `Strict-Transport-Security`. HSTS only protects users in production when the service is actually served over HTTPS. The demo uses an explicit allow-list origin (`EMS_ALLOWED_ORIGIN`, default `http://localhost:5173`) and answers CORS OPTIONS preflight requests. A browser can hide a response from page JavaScript even when the server logged 200 if the CORS response headers are missing or wrong; the matching `Access-Control-Allow-Origin` and correct preflight headers fix that.

The per-client request limit is 120 requests per 60-second window by default. `X-RateLimit-Limit` and `X-RateLimit-Remaining` are returned; when one client exceeds its budget, that client receives `429 Too Many Requests` and `Retry-After`. Other clients have their own budgets.

## Part C — Caching and safe retries

### C1. Conditional GET: 304

A GET of `/exam-sessions/{session_id}` returns an ETag such as `"sha256-..."`. A client that stores this value can send:

```http
GET /exam-sessions/11111111-2222-4333-8444-555555555555 HTTP/1.1
Host: 127.0.0.1:8000
Authorization: Bearer student-token
Accept: application/json
If-None-Match: "sha256-the-etag-returned-by-the-previous-get"
```

If that validator still matches, the server returns `304 Not Modified` with no body. The ETag is computed from the public representation, so a changed session/timer representation gets a different value. This saves sending an unchanged JSON body.

### C2. Conditional write: 412

A staff user first gets `/exam-sessions/{session_id}/timer` and copies its ETag. Then the user sends a full replacement of the writable timer values:

```http
PUT /exam-sessions/11111111-2222-4333-8444-555555555555/timer HTTP/1.1
Host: 127.0.0.1:8000
Authorization: Bearer proctor-token
Accept: application/json
Content-Type: application/json
If-Match: "sha256-old-timer-etag"

{"duration_seconds":7200,"remaining_seconds":3000,"paused_seconds":0}
```

If the timer has changed since the GET, the server returns `412 Precondition Failed`, includes the current ETag, and does not update the timer. This prevents two proctors' or administrators' changes from silently overwriting one another. Missing `If-Match` returns `428 Precondition Required`.

### C3–C4. Safe-retry plan

| Risky operation | Mechanism | Why it fits |
|---|---|---|
| Create a session with `POST /exam-sessions` | `Idempotency-Key` | Retrying after a timeout must not make a second session and timer. The same key/body returns the original result. |
| Read one session or timer | `If-None-Match` | No state changes; 304 avoids retransmitting a representation that has not changed. |
| Replace timer with PUT | `If-Match` + idempotent replacement | Detects stale state. A retry with an old ETag fails with 412 rather than overwriting a newer timer. |
| Terminate session | State-based idempotency | Once it is terminated, repeated calls return the same terminated representation. |
| List and OPTIONS | No write-retry token needed | They do not change an exam session. |

The most damaging accidental duplicate is a repeated create: a student could receive two active attempts for one exam. That is why the create route records the original result with the idempotency key.

## Part D — Verification

`curl-transcript.txt` is generated by calling the local application and its mock dependencies with `curl -v`. It includes: create with 201 and Location, repeating the same create with the same idempotency key, conditional GET returning 304, stale conditional PUT returning 412, malformed JSON returning 400, an unknown session returning 404, and a missing token returning 401. `pytest-output.txt` records the test run, and `openapi-validation.txt` records the OpenAPI structural/reference check. The mock dependencies are local test doubles, not live EMS services.

## Answers to the eight NOTES questions

### 1. Three endpoints: method, success status and most important response header

| Endpoint | Success | Important response header | Why it matters |
|---|---|---|---|
| `POST /exam-sessions` | `201 Created` | `Location` | Tells the client where the newly created session can be read. |
| `GET /exam-sessions/{session_id}` | `200 OK` (or `304` if unchanged) | `ETag` | Gives the client a validator so it can ask whether the session has changed. |
| `PUT /exam-sessions/{session_id}/timer` | `200 OK` | `ETag` | Returns the new validator; the request's `If-Match` stops a stale update from overwriting newer timer values. |

### 2. Which endpoints are safe/idempotent, and how is the risky create retried safely?

The two list/single-item GETs, the timer GET and OPTIONS are safe and idempotent because they do not change the session state. PUT replaces the writable timer values, so its intended effect is idempotent; `If-Match` also detects stale updates. Termination is not safe, but repeating it leaves the session in the same terminated state. `POST /exam-sessions` is the operation that is neither safe nor naturally idempotent: without protection, a repeat could create a second attempt and timer. The `Idempotency-Key` stores the original result for the user; repeating the same key and body returns that result, while using the same key with a different body returns `409 Conflict`.

### 3. ETag example: 304 and 412

This ETag came from the recorded local run:

```http
ETag: "sha256-0fea35756f7d955a2f08c4c054e7eada86752a1261f43fd976dc6dbf67776b08"
```

To check the single session again, the client sends:

```http
GET /exam-sessions/c3ae72f6-9aba-4ad0-b8ab-09bc086db9b0 HTTP/1.1
Host: 127.0.0.1:18000
Authorization: Bearer student-token
Accept: application/json
If-None-Match: "sha256-0fea35756f7d955a2f08c4c054e7eada86752a1261f43fd976dc6dbf67776b08"
```

The server returns `304 Not Modified` with no body if the session still has that ETag. This avoids sending the same JSON representation again. For a write, `PUT /exam-sessions/{id}/timer` with `If-Match: "old-etag"` and a JSON timer body returns `412 Precondition Failed` if that value is not current. The server makes no update and returns the current ETag, preventing an old timer view from overwriting a newer change. Both examples are in `curl-transcript.txt` (the 412 uses a deliberately stale tag).

### 4. Exact requests for 400 and 422

**400 Bad Request — malformed JSON**

```http
POST /exam-sessions HTTP/1.1
Host: 127.0.0.1:18000
Authorization: Bearer student-token
Accept: application/json
Content-Type: application/json
Idempotency-Key: bad-json-example

{"exam_id":
```

This body is not valid JSON, so the request cannot be parsed. It is rejected with `400` before checking whether the exam can be started.

**422 Unprocessable Content — valid request, exam has not opened**

```http
POST /exam-sessions HTTP/1.1
Host: 127.0.0.1:18000
Authorization: Bearer student-token
Accept: application/json
Content-Type: application/json
Idempotency-Key: future-exam-example

{"exam_id":"bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"}
```

That ID is configured in the local dependency mock as an exam whose start time is in the future. The JSON and UUID are valid, but the EMS rule says the student cannot start yet, so the response is `422`. In short, 400 means the request format is bad; 422 means the request is understood but the business rule refuses it.

### 5. Why could the server log 200 while the browser blocks the page?

The browser applies the same-origin policy and CORS checks. The request may reach EMS and the server may log a `200`, but browser JavaScript cannot read that response if the required CORS headers are missing or wrong. EMS must return the allowed origin in `Access-Control-Allow-Origin`; for a preflight it must also answer OPTIONS with suitable `Access-Control-Allow-Methods` and `Access-Control-Allow-Headers`. `Access-Control-Expose-Headers` lets frontend JavaScript read ETag and Location when it needs them. This demo permits the origin configured in `EMS_ALLOWED_ORIGIN`.

### 6. One response that allows caching and one that must not be stored

`GET /exam-sessions/{session_id}` returns `Cache-Control: private, max-age=5, must-revalidate`. A private cache can keep the individual session for a very short period and revalidate it when stale; the ETag enables a 304. `GET /exam-sessions` returns `Cache-Control: no-store` because a list may reveal examination activity for multiple sessions and should not be retained in a cache.

### 7. When could POST be better than GET for search?

GET is right for the EMS session search because its filters are small, can go in the query string, and the operation is a pure read. POST could be justified for a very complex search with a large filter body that exceeds URL length limits or should not appear in a URL. The trade-off is losing the simple GET behaviour—easy bookmarks/sharing and standard cacheability—and the implementation must still make sure that the POST search does not change state.

### 8. What does Location mean on 201 and 3xx?

With `201 Created`, `Location` points to the new resource, for example `/exam-sessions/{session_id}`. With a `3xx` redirect, `Location` points to the alternate URL where the client should continue. The same header is used, but in the first case it identifies a resource that has just been created, while in the second it gives the redirect destination.
