"""HTTP clients for EMS dependencies from the final service design.

These adapters call only the published interfaces of Authentication and Exam
Schedule Management. They never import another service's data store.
"""
from __future__ import annotations

import json
import os
import random
import time
from datetime import datetime
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen
from uuid import uuid4


class UpstreamError(Exception):
    pass


class UpstreamAuthenticationFailed(UpstreamError):
    pass


class UpstreamForbidden(UpstreamError):
    pass


class UpstreamExamNotFound(UpstreamError):
    pass


class UpstreamBadResponse(UpstreamError):
    pass


class UpstreamUnavailable(UpstreamError):
    pass


def _timeout() -> float:
    try:
        return max(0.1, float(os.getenv("EMS_HTTP_TIMEOUT_SECONDS", "1.5")))
    except ValueError:
        return 1.5


def _attempts() -> int:
    try:
        return max(1, min(5, int(os.getenv("EMS_HTTP_MAX_ATTEMPTS", "3"))))
    except ValueError:
        return 3


def _request_json(method: str, url: str, *, headers: dict[str, str] | None = None, body: dict | None = None) -> tuple[int, dict]:
    request_headers = {"Accept": "application/json", **(headers or {})}
    raw_body = None
    if body is not None:
        raw_body = json.dumps(body, separators=(",", ":")).encode("utf-8")
        request_headers["Content-Type"] = "application/json"

    attempts = _attempts()
    last_reason = "upstream service unavailable"
    for attempt in range(attempts):
        req = Request(url, data=raw_body, headers=request_headers, method=method)
        try:
            with urlopen(req, timeout=_timeout()) as response:
                status = response.status
                raw = response.read()
        except HTTPError as exc:
            status = exc.code
            raw = exc.read()
            # Never retry a 4xx response. Retry only server errors.
            if 400 <= status < 500:
                try:
                    payload = json.loads(raw.decode("utf-8")) if raw else {}
                except (ValueError, UnicodeDecodeError):
                    payload = {}
                return status, payload
            last_reason = f"upstream returned HTTP {status}"
            if status < 500 or attempt == attempts - 1:
                raise UpstreamUnavailable(last_reason) from exc
        except (URLError, TimeoutError, OSError) as exc:
            last_reason = "could not connect to upstream service"
            if attempt == attempts - 1:
                raise UpstreamUnavailable(last_reason) from exc
        else:
            if status >= 500:
                last_reason = f"upstream returned HTTP {status}"
                if attempt == attempts - 1:
                    raise UpstreamUnavailable(last_reason)
            else:
                try:
                    payload = json.loads(raw.decode("utf-8")) if raw else {}
                except (ValueError, UnicodeDecodeError) as exc:
                    raise UpstreamBadResponse("upstream response was not valid JSON") from exc
                if not isinstance(payload, dict):
                    raise UpstreamBadResponse("upstream JSON response was not an object")
                return status, payload

        # Exponential backoff plus jitter, only before another safe/retryable attempt.
        if attempt < attempts - 1:
            base = min(0.5, 0.05 * (2 ** attempt))
            time.sleep(base + random.uniform(0, base))

    raise UpstreamUnavailable(last_reason)


def verify_token(token: str) -> dict:
    """Call the Authentication Service's verifyToken() contract via HTTP adapter."""
    base = os.getenv("EMS_AUTH_SERVICE_URL", "").rstrip("/")
    if not base:
        raise UpstreamUnavailable("EMS_AUTH_SERVICE_URL is not configured")
    # Stable across retries of this single POST; generated once, outside the retry loop.
    retry_key = str(uuid4())
    try:
        status, payload = _request_json(
            "POST", base + "/token-verifications",
            headers={"Idempotency-Key": retry_key},
            body={"token": token},
        )
    except UpstreamError:
        raise
    if status == 401:
        raise UpstreamAuthenticationFailed("Access token is invalid or expired")
    if status == 403:
        raise UpstreamForbidden("The token does not have permission for this operation")
    if status >= 400:
        raise UpstreamBadResponse(f"Authentication Service returned unexpected HTTP {status}")
    if payload.get("valid") is not True or not isinstance(payload.get("user_id"), str) or not isinstance(payload.get("roles"), list):
        raise UpstreamBadResponse("Authentication Service response is missing required fields")
    return {"user_id": payload["user_id"], "roles": payload["roles"]}


def fetch_exam_schedule(exam_id: str) -> dict:
    """Call Exam Schedule Management's fetchExamSchedule() contract via HTTP GET."""
    base = os.getenv("EMS_EXAM_SCHEDULE_SERVICE_URL", "").rstrip("/")
    if not base:
        raise UpstreamUnavailable("EMS_EXAM_SCHEDULE_SERVICE_URL is not configured")
    status, payload = _request_json(
        "GET", base + "/exams/" + quote(exam_id, safe=""),
        headers={"Accept": "application/json"},
    )
    if status == 404:
        raise UpstreamExamNotFound("Examination is not present in the schedule")
    if status == 401:
        raise UpstreamAuthenticationFailed("Authentication was rejected by Exam Schedule Management")
    if status == 403:
        raise UpstreamForbidden("Exam Schedule Management denied access")
    if status >= 400:
        raise UpstreamBadResponse(f"Exam Schedule Management returned unexpected HTTP {status}")
    try:
        start_at = datetime.fromisoformat(str(payload["start_at"]).replace("Z", "+00:00"))
        end_at = datetime.fromisoformat(str(payload["end_at"]).replace("Z", "+00:00"))
        duration = int(payload["duration_minutes"])
        status_text = str(payload["status"])
    except (KeyError, ValueError, TypeError) as exc:
        raise UpstreamBadResponse("Exam Schedule Management response is missing valid schedule fields") from exc
    return {"exam_id": exam_id, "start_at": start_at, "end_at": end_at, "duration_minutes": duration, "status": status_text}
