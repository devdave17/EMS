"""Public representations and input validation for EMS exam sessions/timers."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def validate(payload: dict[str, Any], expected_fields: set[str]) -> None:
    if set(payload) != expected_fields:
        missing = sorted(expected_fields - set(payload))
        extra = sorted(set(payload) - expected_fields)
        bits = []
        if missing:
            bits.append("missing field(s): " + ", ".join(missing))
        if extra:
            bits.append("unexpected field(s): " + ", ".join(extra))
        raise ValueError("Invalid request body (" + "; ".join(bits) + ").")


def validate_integer(payload: dict[str, Any], name: str, minimum: int = 0) -> int:
    value = payload.get(name)
    # bool subclasses int in Python, so reject it explicitly.
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer greater than or equal to {minimum}.")
    return value


@dataclass
class SessionTimer:
    timer_id: str
    session_id: str
    started_at: datetime
    duration_seconds: int
    remaining_seconds: int
    paused_seconds: int
    updated_at: datetime

    def as_json(self) -> dict[str, Any]:
        # timer_id stays private; it belongs to the service's internal storage.
        return {
            "session_id": self.session_id,
            "started_at": iso(self.started_at),
            "duration_seconds": self.duration_seconds,
            "remaining_seconds": self.remaining_seconds,
            "paused_seconds": self.paused_seconds,
            "updated_at": iso(self.updated_at),
        }

    def as_embedded_json(self) -> dict[str, Any]:
        return {
            "started_at": iso(self.started_at),
            "duration_seconds": self.duration_seconds,
            "remaining_seconds": self.remaining_seconds,
            "paused_seconds": self.paused_seconds,
            "updated_at": iso(self.updated_at),
        }


@dataclass
class ExamSession:
    session_id: str
    exam_id: str
    student_user_id: str
    session_status: str
    started_at: datetime
    expires_at: datetime
    submitted_at: datetime | None
    timer: SessionTimer
    internal_id: int
    idempotency_key: str
    termination_at: datetime | None = None

    def as_json(self) -> dict[str, Any]:
        # student_user_id, internal_id, idempotency_key and timer_id are not public.
        return {
            "session_id": self.session_id,
            "exam_id": self.exam_id,
            "session_status": self.session_status,
            "started_at": iso(self.started_at),
            "expires_at": iso(self.expires_at),
            "submitted_at": iso(self.submitted_at),
            "timer": self.timer.as_embedded_json(),
        }
