"""Offline OpenAPI structure and local-reference checker.

Uses PyYAML and basic structural checks. If openapi-spec-validator is installed,
its stricter validation is run as well; otherwise the output clearly says so.
"""
from __future__ import annotations
import sys
from pathlib import Path
import yaml

SPEC_PATH = Path(__file__).with_name("openapi.yaml")


class UniqueKeyLoader(yaml.SafeLoader):
    """PyYAML loader that rejects duplicate mapping keys instead of hiding them."""
    def construct_mapping(self, node, deep=False):
        mapping = {}
        for key_node, value_node in node.value:
            key = self.construct_object(key_node, deep=deep)
            if key in mapping:
                raise yaml.constructor.ConstructorError(
                    "while constructing a mapping", node.start_mark,
                    f"duplicate key {key!r}", key_node.start_mark
                )
            mapping[key] = self.construct_object(value_node, deep=deep)
        return mapping


UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    UniqueKeyLoader.construct_mapping,
)


def resolve_pointer(document, ref: str):
    if not ref.startswith("#/" ):
        raise ValueError(f"Only local references are supported by this checker: {ref}")
    value = document
    for part in ref[2:].split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        if not isinstance(value, dict) or part not in value:
            raise ValueError(f"Unresolved $ref: {ref}")
        value = value[part]
    return value


def walk_refs(obj, document, found):
    if isinstance(obj, dict):
        if "$ref" in obj:
            found.add(obj["$ref"])
            resolve_pointer(document, obj["$ref"])
        for value in obj.values():
            walk_refs(value, document, found)
    elif isinstance(obj, list):
        for value in obj:
            walk_refs(value, document, found)


def main() -> int:
    try:
        document = yaml.load(SPEC_PATH.read_text(encoding="utf-8"), Loader=UniqueKeyLoader)
        assert isinstance(document, dict), "top-level YAML value must be an object"
        assert document.get("openapi") == "3.0.3", "expected OpenAPI 3.0.3"
        assert document.get("info", {}).get("title"), "info.title is required"
        assert document.get("info", {}).get("version"), "info.version is required"
        assert document.get("servers"), "servers is required"
        assert document.get("paths"), "paths is required"
        assert document.get("components", {}).get("schemas"), "components.schemas is required"
        methods = {"get", "post", "put", "patch", "delete", "options", "head", "trace"}
        operation_count = 0
        operation_ids = set()
        for path, path_item in document["paths"].items():
            assert path.startswith("/"), f"Path must start with /: {path}"
            for method, operation in path_item.items():
                if method.lower() not in methods:
                    continue
                operation_count += 1
                assert isinstance(operation.get("responses"), dict) and operation["responses"], f"{method} {path} has no responses"
                assert len(operation["responses"]) >= 2, f"{method.upper()} {path} should document at least two responses"
                op_id = operation.get("operationId")
                assert op_id, f"{method.upper()} {path} lacks operationId"
                assert op_id not in operation_ids, f"duplicate operationId: {op_id}"
                operation_ids.add(op_id)
                if method.lower() in {"post", "put", "patch"}:
                    assert "requestBody" in operation, f"{method.upper()} {path} lacks requestBody"
        refs = set()
        walk_refs(document, document, refs)
        print("OpenAPI validation: PASS (structure + duplicate-key + local $ref checks)")
        print(" - OpenAPI version: 3.0.3")
        print(f" - Paths: {len(document['paths'])}")
        print(f" - Operations: {operation_count}")
        print(f" - Component schemas: {len(document['components']['schemas'])}")
        print(f" - Local $ref targets resolved: {len(refs)}")
        print(" - Operations have unique operationId values and documented responses")
        try:
            from openapi_spec_validator import validate as strict_validate
            strict_validate(document)
            print(" - openapi-spec-validator: PASS")
        except ImportError:
            print(" - openapi-spec-validator: not installed in this environment; no claim of strict external validation")
        return 0
    except Exception as exc:
        print(f"OpenAPI validation: FAIL: {exc}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
