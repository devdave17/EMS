from __future__ import annotations
import threading
from http.server import ThreadingHTTPServer

import pytest
import clients
import mock_dependencies


@pytest.fixture
def dependency_server(monkeypatch):
    with mock_dependencies.LOCK:
        mock_dependencies.COUNTS.clear()
        mock_dependencies.AUTH_KEYS.clear()
        mock_dependencies.AUTH_TOKEN_COUNTS.clear()
    server = ThreadingHTTPServer(("127.0.0.1", 0), mock_dependencies.Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    monkeypatch.setenv("EMS_AUTH_SERVICE_URL", base)
    monkeypatch.setenv("EMS_EXAM_SCHEDULE_SERVICE_URL", base)
    monkeypatch.setenv("EMS_HTTP_TIMEOUT_SECONDS", "0.6")
    monkeypatch.setenv("EMS_HTTP_MAX_ATTEMPTS", "3")
    yield base
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)


def test_schedule_get_retries_once_after_503(dependency_server):
    schedule = clients.fetch_exam_schedule(mock_dependencies.RETRY_ONCE_EXAM)
    path = f"/exams/{mock_dependencies.RETRY_ONCE_EXAM}"
    assert schedule["exam_id"] == mock_dependencies.RETRY_ONCE_EXAM
    assert mock_dependencies.COUNTS[path] == 2


def test_auth_post_retry_reuses_same_idempotency_key(dependency_server):
    principal = clients.verify_token("retry-auth-token")
    assert "student" in principal["roles"]
    assert mock_dependencies.AUTH_TOKEN_COUNTS["retry-auth-token"] == 2
    assert len(mock_dependencies.AUTH_KEYS) == 2
    assert mock_dependencies.AUTH_KEYS[0]
    assert mock_dependencies.AUTH_KEYS[0] == mock_dependencies.AUTH_KEYS[1]


def test_auth_4xx_is_not_retried(dependency_server):
    with pytest.raises(clients.UpstreamAuthenticationFailed):
        clients.verify_token("invalid-token")
    assert mock_dependencies.AUTH_TOKEN_COUNTS["invalid-token"] == 1
