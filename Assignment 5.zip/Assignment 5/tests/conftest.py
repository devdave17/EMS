from __future__ import annotations
from datetime import timedelta
import pytest
import app as service_app
from models import utc_now
from store import store

EXAM_ID = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
FUTURE_EXAM_ID = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"
CLOSED_EXAM_ID = "dddddddd-dddd-4ddd-8ddd-dddddddddddd"
UNKNOWN_EXAM_ID = "ffffffff-ffff-4fff-8fff-ffffffffffff"
STUDENT_ID = "11111111-1111-4111-8111-111111111111"
PROCTOR_ID = "22222222-2222-4222-8222-222222222222"


@pytest.fixture(autouse=True)
def clean_state(monkeypatch):
    store.reset()
    service_app.RATE_LIMITER.reset()
    monkeypatch.setattr(service_app, "verify_token", fake_verify_token)
    monkeypatch.setattr(service_app, "fetch_exam_schedule", fake_schedule)
    yield
    store.reset()
    service_app.RATE_LIMITER.reset()


def fake_verify_token(token: str):
    principals = {
        "student-token": {"user_id": STUDENT_ID, "roles": ["student"]},
        "proctor-token": {"user_id": PROCTOR_ID, "roles": ["proctor"]},
        "admin-token": {"user_id": "33333333-3333-4333-8333-333333333333", "roles": ["admin"]},
        "authority-token": {"user_id": "44444444-4444-4444-8444-444444444444", "roles": ["exam_authority"]},
    }
    from clients import UpstreamAuthenticationFailed
    if token not in principals:
        raise UpstreamAuthenticationFailed("Access token is invalid")
    return principals[token]


def fake_schedule(exam_id: str):
    from clients import UpstreamExamNotFound
    if exam_id == UNKNOWN_EXAM_ID:
        raise UpstreamExamNotFound("Exam not found")
    now = utc_now()
    start = now + timedelta(hours=1) if exam_id == FUTURE_EXAM_ID else now - timedelta(hours=1)
    status = "closed" if exam_id == CLOSED_EXAM_ID else "scheduled"
    return {"exam_id": exam_id, "status": status, "start_at": start,
            "end_at": now + timedelta(hours=2), "duration_minutes": 120}
