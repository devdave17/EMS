from __future__ import annotations
import json
from datetime import timedelta

import app as service_app
from app import RateLimiter
from models import utc_now
from store import store
from tests.helpers import call_app, create_session

EXAM_ID = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
FUTURE_ID = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"
CLOSED_ID = "dddddddd-dddd-4ddd-8ddd-dddddddddddd"
UNKNOWN_ID = "ffffffff-ffff-4fff-8fff-ffffffffffff"


def test_create_returns_201_location_and_private_public_representation():
    response = create_session(service_app)
    assert response["status"] == 201
    assert response["headers"]["Location"].startswith("/exam-sessions/")
    assert response["headers"]["ETag"].startswith('"sha256-')
    assert response["headers"]["Cache-Control"] == "no-store"
    assert response["headers"]["X-Content-Type-Options"] == "nosniff"
    assert "student_user_id" not in response["body"]
    assert "timer_id" not in response["body"]["timer"]
    assert "idempotency_key" not in json.dumps(response["body"])


def test_create_repeat_with_same_idempotency_key_returns_original():
    first = create_session(service_app, key="same-create-key")
    second = create_session(service_app, key="same-create-key")
    assert first["status"] == second["status"] == 201
    assert first["body"] == second["body"]
    assert first["headers"]["Location"] == second["headers"]["Location"]
    assert len(store.list_sessions()) == 1


def test_same_idempotency_key_with_different_body_is_409():
    first = create_session(service_app, key="conflicting-key", exam_id=EXAM_ID)
    second = create_session(service_app, key="conflicting-key", exam_id=UNKNOWN_ID)
    assert first["status"] == 201
    assert second["status"] == 409
    assert second["body"]["type"].endswith("idempotency-key-conflict")


def test_missing_authorization_is_401():
    response = call_app(service_app, "GET", "/exam-sessions", token=None)
    assert response["status"] == 401
    assert response["body"]["status"] == 401
    assert response["headers"]["Content-Type"].startswith("application/json")


def test_malformed_body_is_400_and_consistent_error_shape():
    response = call_app(service_app, "POST", "/exam-sessions", token="student-token",
                        headers={"Content-Type": "application/json", "Idempotency-Key": "bad-json"}, raw=b'{"exam_id":')
    assert response["status"] == 400
    assert set(response["body"]) == {"type", "title", "status", "detail"}


def test_unsupported_accept_is_406():
    response = call_app(service_app, "GET", "/exam-sessions", headers={"Accept": "text/html"})
    assert response["status"] == 406


def test_valid_but_not_yet_open_exam_is_422():
    response = create_session(service_app, key="future-exam", exam_id=FUTURE_ID)
    assert response["status"] == 422
    assert response["body"]["type"].endswith("exam-not-open")


def test_single_item_get_has_etag_and_if_none_match_returns_304():
    created = create_session(service_app)
    path = created["headers"]["Location"]
    first = call_app(service_app, "GET", path)
    assert first["status"] == 200
    assert first["headers"]["ETag"]
    second = call_app(service_app, "GET", path, headers={"If-None-Match": first["headers"]["ETag"]})
    assert second["status"] == 304
    assert second["body"] is None
    assert second["headers"]["ETag"] == first["headers"]["ETag"]


def test_missing_session_is_404():
    response = call_app(service_app, "GET", f"/exam-sessions/{UNKNOWN_ID}")
    assert response["status"] == 404


def test_list_query_supports_filter_sort_and_pagination():
    create_session(service_app, key="page-1")
    create_session(service_app, key="page-2")
    response = call_app(service_app, "GET", f"/exam-sessions?exam_id={EXAM_ID}&status=active&sort=-started_at&limit=1&offset=0")
    assert response["status"] == 200
    assert response["body"]["total"] == 2
    assert response["body"]["limit"] == 1
    assert len(response["body"]["items"]) == 1
    assert response["headers"]["Cache-Control"] == "no-store"


def test_timer_etag_conditional_put_and_stale_write_412():
    created = create_session(service_app)
    session_id = created["body"]["session_id"]
    timer_path = f"/exam-sessions/{session_id}/timer"
    current = call_app(service_app, "GET", timer_path, token="proctor-token")
    assert current["status"] == 200
    assert current["headers"]["ETag"]

    stale = call_app(service_app, "PUT", timer_path,
                     body={"duration_seconds": 7200, "remaining_seconds": 3000, "paused_seconds": 0},
                     token="proctor-token", headers={"If-Match": '"old-version"'})
    assert stale["status"] == 412
    assert stale["headers"]["ETag"] == current["headers"]["ETag"]

    updated = call_app(service_app, "PUT", timer_path,
                       body={"duration_seconds": 7200, "remaining_seconds": 3000, "paused_seconds": 0},
                       token="proctor-token", headers={"If-Match": current["headers"]["ETag"]})
    assert updated["status"] == 200
    assert updated["body"]["remaining_seconds"] == 3000
    assert updated["headers"]["ETag"] != current["headers"]["ETag"]


def test_put_without_if_match_returns_428():
    created = create_session(service_app)
    timer_path = f"/exam-sessions/{created['body']['session_id']}/timer"
    response = call_app(service_app, "PUT", timer_path,
                        body={"duration_seconds": 7200, "remaining_seconds": 3500, "paused_seconds": 0}, token="proctor-token")
    assert response["status"] == 428


def test_timer_update_domain_refusal_is_422():
    created = create_session(service_app)
    timer_path = f"/exam-sessions/{created['body']['session_id']}/timer"
    current = call_app(service_app, "GET", timer_path, token="proctor-token")
    response = call_app(service_app, "PUT", timer_path,
                        body={"duration_seconds": 100, "remaining_seconds": 200, "paused_seconds": 0},
                        token="proctor-token", headers={"If-Match": current["headers"]["ETag"]})
    assert response["status"] == 422


def test_termination_is_a_post_subresource_and_repeat_has_same_effect():
    created = create_session(service_app)
    path = f"/exam-sessions/{created['body']['session_id']}/termination"
    first = call_app(service_app, "POST", path, body={"confirm": True}, token="proctor-token")
    second = call_app(service_app, "POST", path, body={"confirm": True}, token="proctor-token")
    assert first["status"] == second["status"] == 200
    assert first["body"] == second["body"]
    assert first["body"]["session_status"] == "terminated"
    assert first["body"]["timer"]["remaining_seconds"] == 0


def test_options_allow_and_cors_preflight_headers():
    response = call_app(service_app, "OPTIONS", "/exam-sessions/11111111-1111-4111-8111-111111111111/timer",
                        token=None, headers={"Origin": "http://localhost:5173",
                                             "Access-Control-Request-Method": "PUT",
                                             "Access-Control-Request-Headers": "authorization, content-type, if-match"})
    assert response["status"] == 204
    assert "PUT" in response["headers"]["Allow"]
    assert response["headers"]["Access-Control-Allow-Origin"] == "http://localhost:5173"
    assert "Access-Control-Allow-Methods" in response["headers"]
    assert "Access-Control-Allow-Headers" in response["headers"]


def test_method_override_fallback_uses_post_header_to_apply_put():
    created = create_session(service_app)
    timer_path = f"/exam-sessions/{created['body']['session_id']}/timer"
    current = call_app(service_app, "GET", timer_path, token="proctor-token")
    response = call_app(service_app, "POST", timer_path,
                        body={"duration_seconds": 7200, "remaining_seconds": 2500, "paused_seconds": 0},
                        token="proctor-token", headers={"X-HTTP-Method-Override": "PUT", "If-Match": current["headers"]["ETag"]})
    assert response["status"] == 200
    assert response["body"]["remaining_seconds"] == 2500


def test_gzip_is_used_for_large_json_response():
    for number in range(6):
        create_session(service_app, key=f"gzip-{number}")
    response = call_app(service_app, "GET", "/exam-sessions", headers={"Accept-Encoding": "gzip"})
    assert response["status"] == 200
    assert response["headers"].get("Content-Encoding") == "gzip"
    assert len(response["body"]["items"]) == 6
    assert "Accept-Encoding" in response["headers"].get("Vary", "")


def test_rate_limit_is_per_client_and_returns_retry_after(monkeypatch):
    monkeypatch.setattr(service_app, "RATE_LIMITER", RateLimiter(limit=1, window_seconds=60))
    first = call_app(service_app, "GET", "/exam-sessions", remote="192.0.2.45")
    second = call_app(service_app, "GET", "/exam-sessions", remote="192.0.2.45")
    third = call_app(service_app, "GET", "/exam-sessions", remote="192.0.2.46")
    assert first["status"] == 200
    assert second["status"] == 429
    assert second["headers"]["Retry-After"]
    assert second["headers"]["X-RateLimit-Remaining"] == "0"
    assert third["status"] == 200


def test_common_security_and_rate_limit_headers_exist():
    response = call_app(service_app, "GET", "/exam-sessions", headers={"Origin": "http://localhost:5173"})
    assert response["headers"]["X-Content-Type-Options"] == "nosniff"
    assert response["headers"]["Strict-Transport-Security"].startswith("max-age=")
    assert response["headers"]["X-RateLimit-Limit"]
    assert response["headers"]["X-RateLimit-Remaining"]
    assert response["headers"]["Access-Control-Allow-Origin"] == "http://localhost:5173"
