from __future__ import annotations
import json
import gzip
from io import BytesIO
from urllib.parse import urlsplit
from uuid import uuid4


def call_app(app, method="GET", path="/", body=None, token="student-token", headers=None, remote=None, raw=None):
    headers = dict(headers or {})
    split = urlsplit(path)
    raw_body = raw if raw is not None else (json.dumps(body).encode("utf-8") if body is not None else b"")
    content_type = headers.pop("Content-Type", "application/json" if body is not None or raw is not None else "")
    environ = {
        "REQUEST_METHOD": method.upper(), "PATH_INFO": split.path, "QUERY_STRING": split.query,
        "CONTENT_TYPE": content_type, "CONTENT_LENGTH": str(len(raw_body)),
        "wsgi.input": BytesIO(raw_body), "wsgi.url_scheme": "http", "SERVER_NAME": "localhost",
        "SERVER_PORT": "8000", "SERVER_PROTOCOL": "HTTP/1.1", "REMOTE_ADDR": remote or f"test-{uuid4()}",
        "wsgi.version": (1, 0), "wsgi.errors": BytesIO(), "wsgi.multithread": False,
        "wsgi.multiprocess": False, "wsgi.run_once": False,
    }
    if token is not None:
        environ["HTTP_AUTHORIZATION"] = f"Bearer {token}"
    for key, value in headers.items():
        normalized = key.upper().replace("-", "_")
        if normalized in {"CONTENT_TYPE", "CONTENT_LENGTH"}:
            environ[normalized] = value
        else:
            environ["HTTP_" + normalized] = value
    captured = {}

    def start_response(status, response_headers, exc_info=None):
        captured["status"] = int(status.split()[0])
        captured["headers"] = {k: v for k, v in response_headers}

    output = b"".join(app.application(environ, start_response))
    if captured["headers"].get("Content-Encoding") == "gzip":
        output = gzip.decompress(output)
    captured["raw_body"] = output
    captured["body"] = json.loads(output.decode("utf-8")) if output else None
    return captured


def create_session(app, key="test-create-1", exam_id="aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"):
    return call_app(app, "POST", "/exam-sessions", body={"exam_id": exam_id},
                    headers={"Idempotency-Key": key})
