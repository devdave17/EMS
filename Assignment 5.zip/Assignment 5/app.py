"""EMS Online Examination Service — Assignment 5 HTTP methods and headers.

This WSGI implementation is a teaching/demo service. It owns only the
exam_sessions and session_timers data defined for the Online Examination
Service. Authentication and exam schedules are obtained through HTTP contracts.
"""
from __future__ import annotations

import gzip
import hashlib
import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any, Callable
from urllib.parse import parse_qs
from uuid import UUID, uuid4
from wsgiref.simple_server import make_server

from clients import (
    UpstreamAuthenticationFailed,
    UpstreamBadResponse,
    UpstreamExamNotFound,
    UpstreamForbidden,
    UpstreamUnavailable,
    fetch_exam_schedule,
    verify_token,
)
from errors import ApiError, problem
from models import ExamSession, SessionTimer, utc_now, validate, validate_integer
from store import IdempotencyConflict, store

STAFF_ROLES = {"admin", "proctor", "exam_authority"}
ALLOWED_SESSION_FILTERS = {"active", "submitted", "terminated"}
MAX_BODY_BYTES = 64 * 1024
GZIP_THRESHOLD_BYTES = 1024
ALLOWED_ORIGIN = os.getenv("EMS_ALLOWED_ORIGIN", "http://localhost:5173")


@dataclass
class Response:
    status: int
    body: bytes = b""
    headers: dict[str, str] = field(default_factory=dict)

    @classmethod
    def json(cls, status: int, payload: dict | list, headers: dict[str, str] | None = None) -> "Response":
        raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
        result_headers = {"Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store"}
        result_headers.update(headers or {})
        return cls(status, raw, result_headers)

    @classmethod
    def empty(cls, status: int, headers: dict[str, str] | None = None) -> "Response":
        return cls(status, b"", dict(headers or {}))


class RateLimiter:
    """Simple in-memory per-client fixed-window limiter for the lab demo."""
    def __init__(self, limit: int = 120, window_seconds: int = 60) -> None:
        self.limit = max(1, limit)
        self.window_seconds = max(1, window_seconds)
        self._lock = threading.Lock()
        self._buckets: dict[str, tuple[int, int]] = {}

    def check(self, client: str, now: float | None = None) -> tuple[bool, int, int, int]:
        now = time.monotonic() if now is None else now
        window = int(now // self.window_seconds)
        with self._lock:
            old_window, used = self._buckets.get(client, (window, 0))
            if old_window != window:
                used = 0
            used += 1
            self._buckets[client] = (window, used)
            remaining = max(0, self.limit - used)
            retry_after = max(1, self.window_seconds - int(now % self.window_seconds))
            return used <= self.limit, self.limit, remaining, retry_after

    def reset(self) -> None:
        with self._lock:
            self._buckets.clear()


RATE_LIMITER = RateLimiter(int(os.getenv("EMS_RATE_LIMIT", "120")))


_STATUS_TEXT = {
    200: "OK", 201: "Created", 204: "No Content", 304: "Not Modified",
    400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
    405: "Method Not Allowed", 406: "Not Acceptable", 409: "Conflict",
    412: "Precondition Failed", 413: "Payload Too Large", 415: "Unsupported Media Type",
    422: "Unprocessable Content", 428: "Precondition Required", 429: "Too Many Requests",
    500: "Internal Server Error", 502: "Bad Gateway", 503: "Service Unavailable",
}


def _json_error(error: ApiError) -> Response:
    headers = dict(error.headers)
    return Response.json(error.status, problem(error), headers)


def _valid_uuid(value: Any, field_name: str) -> str:
    if not isinstance(value, str):
        raise ApiError(400, "Bad Request", f"{field_name} must be a UUID string.", "invalid-identifier")
    try:
        return str(UUID(value))
    except (ValueError, TypeError, AttributeError) as exc:
        raise ApiError(400, "Bad Request", f"{field_name} must be a valid UUID.", "invalid-identifier") from exc


def _parse_json_body(environ: dict[str, Any]) -> dict[str, Any]:
    content_type = environ.get("CONTENT_TYPE", "").split(";", 1)[0].strip().lower()
    if content_type != "application/json":
        raise ApiError(415, "Unsupported Media Type", "Content-Type must be application/json.", "unsupported-media-type")
    try:
        length = int(environ.get("CONTENT_LENGTH") or "0")
    except ValueError as exc:
        raise ApiError(400, "Bad Request", "Content-Length is invalid.", "malformed-request") from exc
    if length < 0:
        raise ApiError(400, "Bad Request", "Content-Length must not be negative.", "malformed-request")
    if length > MAX_BODY_BYTES:
        raise ApiError(413, "Payload Too Large", "Request body is too large.", "payload-too-large")
    raw = environ["wsgi.input"].read(length) if length else b""
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ApiError(400, "Bad Request", "Request body must contain valid JSON.", "malformed-request") from exc
    if not isinstance(payload, dict):
        raise ApiError(400, "Bad Request", "Request body must be a JSON object.", "malformed-request")
    return payload


def _validate_body(payload: dict[str, Any], expected_fields: set[str]) -> None:
    try:
        validate(payload, expected_fields)
    except ValueError as exc:
        raise ApiError(400, "Bad Request", str(exc), "invalid-request-shape") from exc


def _check_accept(environ: dict[str, Any]) -> None:
    accept = environ.get("HTTP_ACCEPT", "*/*").strip().lower()
    if not accept or "*/*" in accept or "application/json" in accept or "application/*" in accept or "application/problem+json" in accept:
        return
    raise ApiError(406, "Not Acceptable", "This API returns JSON; request application/json in the Accept header.", "not-acceptable")


def _bearer_token(environ: dict[str, Any]) -> str:
    header = environ.get("HTTP_AUTHORIZATION", "")
    match = re.fullmatch(r"Bearer\s+([^\s]+)", header.strip(), flags=re.IGNORECASE)
    if not match:
        raise ApiError(401, "Unauthorized", "A non-empty Bearer access token is required.", "authentication-required")
    return match.group(1)


def _principal(environ: dict[str, Any]) -> dict[str, Any]:
    token = _bearer_token(environ)
    try:
        return verify_token(token)
    except UpstreamAuthenticationFailed as exc:
        raise ApiError(401, "Unauthorized", "The access token is invalid or expired.", "invalid-token") from exc
    except UpstreamForbidden as exc:
        raise ApiError(403, "Forbidden", "The access token does not permit this operation.", "access-denied") from exc
    except UpstreamUnavailable as exc:
        raise ApiError(503, "Service Unavailable", "Authentication cannot be checked right now. Please retry later.", "authentication-unavailable") from exc
    except UpstreamBadResponse as exc:
        raise ApiError(502, "Bad Gateway", "Authentication Service returned an invalid response.", "invalid-dependency-response") from exc


def _require_role(principal: dict[str, Any], allowed_roles: set[str]) -> None:
    if not set(principal.get("roles", [])).intersection(allowed_roles):
        raise ApiError(403, "Forbidden", "Your role is not allowed to perform this operation.", "role-not-permitted")


def _can_view(principal: dict[str, Any], session: ExamSession) -> bool:
    return session.student_user_id == principal["user_id"] or bool(set(principal.get("roles", [])).intersection(STAFF_ROLES))


def _etag(representation: dict[str, Any]) -> str:
    raw = json.dumps(representation, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return '"sha256-' + hashlib.sha256(raw).hexdigest() + '"'


def _etag_matches(header: str, current: str) -> bool:
    if not header:
        return False
    candidates = [part.strip() for part in header.split(",") if part.strip()]
    for candidate in candidates:
        if candidate == "*":
            return True
        normalized = candidate[2:].strip() if candidate.startswith("W/") else candidate
        if normalized == current:
            return True
    return False


def _schedule_for_start(exam_id: str) -> dict[str, Any]:
    try:
        schedule = fetch_exam_schedule(exam_id)
    except UpstreamExamNotFound as exc:
        raise ApiError(422, "Exam cannot be started", "The requested examination is not available in the schedule.", "exam-not-available") from exc
    except UpstreamUnavailable as exc:
        raise ApiError(503, "Service Unavailable", "Exam Schedule Management is temporarily unavailable. Please retry later.", "schedule-service-unavailable") from exc
    except UpstreamBadResponse as exc:
        raise ApiError(502, "Bad Gateway", "Exam Schedule Management returned an invalid response.", "invalid-dependency-response") from exc

    now = utc_now()
    if str(schedule["status"]).lower() not in {"scheduled", "published"}:
        raise ApiError(422, "Exam cannot be started", "The examination is not in a startable state.", "exam-not-startable")
    if now < schedule["start_at"]:
        raise ApiError(422, "Exam has not started", "The examination start time has not arrived.", "exam-not-open")
    if now >= schedule["end_at"]:
        raise ApiError(422, "Exam has ended", "The examination end time has passed.", "exam-window-closed")
    if int(schedule["duration_minutes"]) <= 0:
        raise ApiError(502, "Bad Gateway", "Exam Schedule Management returned an invalid duration.", "invalid-dependency-response")
    return schedule


def _parse_query(environ: dict[str, Any]) -> dict[str, Any]:
    query = parse_qs(environ.get("QUERY_STRING", ""), keep_blank_values=True, strict_parsing=False)
    allowed = {"exam_id", "status", "sort", "limit", "offset"}
    unknown = set(query) - allowed
    if unknown:
        raise ApiError(400, "Bad Request", "Unsupported query parameter(s): " + ", ".join(sorted(unknown)) + ".", "invalid-query")
    result: dict[str, Any] = {}
    for key, values in query.items():
        if len(values) != 1 or not values[0].strip():
            raise ApiError(400, "Bad Request", f"Query parameter {key} must appear once and must not be empty.", "invalid-query")
        result[key] = values[0].strip()
    if "exam_id" in result:
        result["exam_id"] = _valid_uuid(result["exam_id"], "exam_id")
    if "status" in result and result["status"] not in ALLOWED_SESSION_FILTERS:
        raise ApiError(400, "Bad Request", "status must be active, submitted, or terminated.", "invalid-query")
    if "sort" in result and result["sort"] not in {"started_at", "-started_at"}:
        raise ApiError(400, "Bad Request", "sort must be started_at or -started_at.", "invalid-query")
    try:
        limit = int(result.get("limit", "20"))
        offset = int(result.get("offset", "0"))
    except ValueError as exc:
        raise ApiError(400, "Bad Request", "limit and offset must be integers.", "invalid-query") from exc
    if not 1 <= limit <= 100 or offset < 0:
        raise ApiError(400, "Bad Request", "limit must be 1-100 and offset must be zero or greater.", "invalid-query")
    result["limit"] = limit
    result["offset"] = offset
    result["sort"] = result.get("sort", "-started_at")
    return result


def _start_session(environ: dict[str, Any]) -> Response:
    payload = _parse_json_body(environ)
    _validate_body(payload, {"exam_id"})
    exam_id = _valid_uuid(payload["exam_id"], "exam_id")
    idempotency_key = environ.get("HTTP_IDEMPOTENCY_KEY", "").strip()
    if not idempotency_key or len(idempotency_key) > 200:
        raise ApiError(400, "Bad Request", "Idempotency-Key is required and must be at most 200 characters.", "idempotency-key-required")

    principal = _principal(environ)
    _require_role(principal, {"student"})
    user_id = principal["user_id"]
    fingerprint = store.fingerprint({"exam_id": exam_id})
    try:
        existing = store.idempotent_session(user_id, idempotency_key, fingerprint)
    except IdempotencyConflict as exc:
        raise ApiError(409, "Conflict", str(exc), "idempotency-key-conflict") from exc
    if existing is not None:
        body = existing.as_json()
        return Response.json(201, body, {"Location": f"/exam-sessions/{existing.session_id}", "ETag": _etag(body), "Cache-Control": "no-store"})

    schedule = _schedule_for_start(exam_id)
    now = utc_now()
    expires_at = min(now + timedelta(minutes=int(schedule["duration_minutes"])), schedule["end_at"])

    def factory(internal_id: int) -> ExamSession:
        session_id = str(uuid4())
        timer = SessionTimer(
            timer_id=str(uuid4()), session_id=session_id, started_at=now,
            duration_seconds=max(0, int((expires_at - now).total_seconds())),
            remaining_seconds=max(0, int((expires_at - now).total_seconds())),
            paused_seconds=0, updated_at=now,
        )
        return ExamSession(
            session_id=session_id, exam_id=exam_id, student_user_id=user_id,
            session_status="active", started_at=now, expires_at=expires_at,
            submitted_at=None, timer=timer, internal_id=internal_id,
            idempotency_key=idempotency_key,
        )

    try:
        session, _created_now = store.create_session_idempotent(factory, user_id, idempotency_key, fingerprint)
    except IdempotencyConflict as exc:
        raise ApiError(409, "Conflict", str(exc), "idempotency-key-conflict") from exc
    body = session.as_json()
    return Response.json(201, body, {"Location": f"/exam-sessions/{session.session_id}", "ETag": _etag(body), "Cache-Control": "no-store"})


def _get_session(environ: dict[str, Any], session_id_raw: str) -> Response:
    session_id = _valid_uuid(session_id_raw, "session_id")
    principal = _principal(environ)
    session = store.get(session_id)
    if session is None:
        raise ApiError(404, "Not Found", "No examination session exists with that identifier.", "session-not-found")
    if not _can_view(principal, session):
        raise ApiError(403, "Forbidden", "You may only view your own sessions unless you have an authorized staff role.", "access-denied")
    body = session.as_json()
    etag = _etag(body)
    headers = {"ETag": etag, "Cache-Control": "private, max-age=5, must-revalidate"}
    if _etag_matches(environ.get("HTTP_IF_NONE_MATCH", ""), etag):
        return Response.empty(304, headers)
    return Response.json(200, body, headers)


def _list_sessions(environ: dict[str, Any]) -> Response:
    principal = _principal(environ)
    filters = _parse_query(environ)
    sessions = store.list_sessions()
    if not set(principal.get("roles", [])).intersection(STAFF_ROLES):
        sessions = [session for session in sessions if session.student_user_id == principal["user_id"]]
    if "exam_id" in filters:
        sessions = [session for session in sessions if session.exam_id == filters["exam_id"]]
    if "status" in filters:
        sessions = [session for session in sessions if session.session_status == filters["status"]]
    sessions.sort(key=lambda item: item.started_at, reverse=filters["sort"] == "-started_at")
    total = len(sessions)
    page = sessions[filters["offset"]:filters["offset"] + filters["limit"]]
    body = {"items": [item.as_json() for item in page], "total": total, "limit": filters["limit"], "offset": filters["offset"], "sort": filters["sort"]}
    return Response.json(200, body, {"Cache-Control": "no-store"})


def _terminate_session(environ: dict[str, Any], session_id_raw: str) -> Response:
    session_id = _valid_uuid(session_id_raw, "session_id")
    payload = _parse_json_body(environ)
    _validate_body(payload, {"confirm"})
    if payload["confirm"] is not True:
        raise ApiError(400, "Bad Request", "confirm must be true to terminate a session.", "termination-not-confirmed")
    principal = _principal(environ)
    _require_role(principal, STAFF_ROLES)
    session = store.terminate(session_id)
    if session is None:
        raise ApiError(404, "Not Found", "No examination session exists with that identifier.", "session-not-found")
    # Repeating this request returns the same terminated state; the effect is idempotent.
    return Response.json(200, session.as_json(), {"Cache-Control": "no-store", "ETag": _etag(session.as_json())})


def _get_timer(environ: dict[str, Any], session_id_raw: str) -> Response:
    session_id = _valid_uuid(session_id_raw, "session_id")
    principal = _principal(environ)
    session = store.get(session_id)
    if session is None:
        raise ApiError(404, "Not Found", "No examination session exists with that identifier.", "session-not-found")
    if not _can_view(principal, session):
        raise ApiError(403, "Forbidden", "You may only view your own session timer unless you have an authorized staff role.", "access-denied")
    body = session.timer.as_json()
    etag = _etag(body)
    headers = {"ETag": etag, "Cache-Control": "private, max-age=0, must-revalidate"}
    if _etag_matches(environ.get("HTTP_IF_NONE_MATCH", ""), etag):
        return Response.empty(304, headers)
    return Response.json(200, body, headers)


def _put_timer(environ: dict[str, Any], session_id_raw: str) -> Response:
    session_id = _valid_uuid(session_id_raw, "session_id")
    payload = _parse_json_body(environ)
    _validate_body(payload, {"duration_seconds", "remaining_seconds", "paused_seconds"})
    try:
        duration = validate_integer(payload, "duration_seconds", 1)
        remaining = validate_integer(payload, "remaining_seconds", 0)
        paused = validate_integer(payload, "paused_seconds", 0)
    except ValueError as exc:
        raise ApiError(400, "Bad Request", str(exc), "invalid-request-shape") from exc
    principal = _principal(environ)
    _require_role(principal, {"admin", "proctor", "exam_authority"})
    session = store.get(session_id)
    if session is None:
        raise ApiError(404, "Not Found", "No examination session exists with that identifier.", "session-not-found")
    if session.session_status != "active":
        raise ApiError(409, "Conflict", "Only an active examination session's timer can be updated.", "session-state-conflict")
    current = _etag(session.timer.as_json())
    supplied = environ.get("HTTP_IF_MATCH", "").strip()
    if not supplied:
        raise ApiError(428, "Precondition Required", "If-Match is required; first retrieve the timer and use its ETag.", "if-match-required", (("ETag", current),))
    if not _etag_matches(supplied, current):
        raise ApiError(412, "Precondition Failed", "The timer changed since it was read. Retrieve the current timer and retry your update.", "etag-mismatch", (("ETag", current),))
    if remaining > duration or paused > duration:
        raise ApiError(422, "Timer values rejected", "remaining_seconds and paused_seconds cannot exceed duration_seconds.", "invalid-timer-values")
    session = store.update_timer(session_id, duration, remaining, paused)
    body = session.timer.as_json()
    return Response.json(200, body, {"ETag": _etag(body), "Cache-Control": "private, no-cache"})


def _allow_for_path(path: str) -> str | None:
    if path == "/exam-sessions":
        return "GET, POST, OPTIONS"
    if re.fullmatch(r"/exam-sessions/[^/]+", path):
        return "GET, OPTIONS"
    if re.fullmatch(r"/exam-sessions/[^/]+/termination", path):
        return "POST, OPTIONS"
    if re.fullmatch(r"/exam-sessions/[^/]+/timer", path):
        # POST is present only as the documented method-override fallback for PUT.
        return "GET, PUT, POST, OPTIONS"
    return None


def _options(environ: dict[str, Any], path: str) -> Response:
    allow = _allow_for_path(path)
    if allow is None:
        raise ApiError(404, "Not Found", "The requested endpoint does not exist.", "endpoint-not-found")
    headers = {"Allow": allow}
    requested_method = environ.get("HTTP_ACCESS_CONTROL_REQUEST_METHOD", "").upper()
    if requested_method:
        allowed_methods = {part.strip() for part in allow.split(",")}
        if requested_method not in allowed_methods:
            raise ApiError(403, "Forbidden", "The requested CORS method is not allowed for this resource.", "cors-method-not-allowed")
        headers["Access-Control-Allow-Methods"] = allow
        requested_headers = environ.get("HTTP_ACCESS_CONTROL_REQUEST_HEADERS", "")
        allowed_headers = {"authorization", "content-type", "accept", "idempotency-key", "if-none-match", "if-match", "x-http-method-override"}
        requested = {item.strip().lower() for item in requested_headers.split(",") if item.strip()}
        if not requested.issubset(allowed_headers):
            raise ApiError(403, "Forbidden", "One or more requested CORS headers are not allowed.", "cors-header-not-allowed")
        headers["Access-Control-Allow-Headers"] = ", ".join(sorted(allowed_headers))
        headers["Access-Control-Max-Age"] = "600"
    return Response.empty(204, headers)


def _dispatch(environ: dict[str, Any], method: str, path: str) -> Response:
    if method == "OPTIONS":
        return _options(environ, path)
    if path == "/exam-sessions":
        if method == "POST":
            return _start_session(environ)
        if method == "GET":
            return _list_sessions(environ)
        raise ApiError(405, "Method Not Allowed", "Use GET or POST for /exam-sessions.", "method-not-allowed", (("Allow", "GET, POST, OPTIONS"),))

    match = re.fullmatch(r"/exam-sessions/([^/]+)/termination", path)
    if match:
        if method == "POST":
            return _terminate_session(environ, match.group(1))
        raise ApiError(405, "Method Not Allowed", "Use POST to request session termination.", "method-not-allowed", (("Allow", "POST, OPTIONS"),))

    match = re.fullmatch(r"/exam-sessions/([^/]+)/timer", path)
    if match:
        if method == "GET":
            return _get_timer(environ, match.group(1))
        if method == "PUT":
            return _put_timer(environ, match.group(1))
        raise ApiError(405, "Method Not Allowed", "Use GET or PUT for the timer resource.", "method-not-allowed", (("Allow", "GET, PUT, POST, OPTIONS"),))

    match = re.fullmatch(r"/exam-sessions/([^/]+)", path)
    if match:
        if method == "GET":
            return _get_session(environ, match.group(1))
        raise ApiError(405, "Method Not Allowed", "Use GET to read an examination session.", "method-not-allowed", (("Allow", "GET, OPTIONS"),))
    raise ApiError(404, "Not Found", "The requested endpoint does not exist.", "endpoint-not-found")


def _merge_vary(current: str | None, value: str) -> str:
    parts = [part.strip() for part in (current or "").split(",") if part.strip()]
    if value.lower() not in {part.lower() for part in parts}:
        parts.append(value)
    return ", ".join(parts)


def _finalize(response: Response, environ: dict[str, Any], limit: int, remaining: int, retry_after: int | None) -> tuple[str, list[tuple[str, str]], bytes]:
    headers = dict(response.headers)
    # Security headers are explicit. The production deployment must serve HTTPS.
    headers.setdefault("X-Content-Type-Options", "nosniff")
    headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    headers["X-RateLimit-Limit"] = str(limit)
    headers["X-RateLimit-Remaining"] = str(remaining)
    if retry_after is not None:
        headers["Retry-After"] = str(retry_after)

    origin = environ.get("HTTP_ORIGIN", "")
    if origin and origin == ALLOWED_ORIGIN:
        headers["Access-Control-Allow-Origin"] = ALLOWED_ORIGIN
        headers["Access-Control-Expose-Headers"] = "ETag, Location, X-RateLimit-Limit, X-RateLimit-Remaining, Retry-After"
        headers["Vary"] = _merge_vary(headers.get("Vary"), "Origin")

    body = response.body
    no_body_status = response.status in {204, 304}
    if not no_body_status:
        headers.setdefault("Content-Type", "application/json; charset=utf-8")
        if body and len(body) >= GZIP_THRESHOLD_BYTES and re.search(r"(?:^|,)\s*gzip\s*(?:,|$)", environ.get("HTTP_ACCEPT_ENCODING", ""), re.IGNORECASE):
            body = gzip.compress(body, mtime=0)
            headers["Content-Encoding"] = "gzip"
            headers["Vary"] = _merge_vary(headers.get("Vary"), "Accept-Encoding")
        headers["Content-Length"] = str(len(body))
    else:
        headers.pop("Content-Type", None)
        headers.pop("Content-Length", None)
        body = b""

    status_text = _STATUS_TEXT.get(response.status, "Response")
    return f"{response.status} {status_text}", list(headers.items()), body


def application(environ: dict[str, Any], start_response: Callable) -> list[bytes]:
    raw_method = environ.get("REQUEST_METHOD", "GET").upper()
    method = raw_method
    path = environ.get("PATH_INFO", "/")
    remote = environ.get("REMOTE_ADDR", "unknown-client")

    allowed, limit, remaining, retry_after = RATE_LIMITER.check(remote)

    try:
        if not allowed:
            response = _json_error(ApiError(429, "Too Many Requests", "This client's request budget is exhausted. Wait before retrying.", "rate-limit-exceeded"))
            # Include Retry-After for this response.
        else:
            if raw_method == "POST" and environ.get("HTTP_X_HTTP_METHOD_OVERRIDE", "").strip():
                override = environ["HTTP_X_HTTP_METHOD_OVERRIDE"].strip().upper()
                if override == "PUT" and re.fullmatch(r"/exam-sessions/[^/]+/timer", path):
                    method = "PUT"
                else:
                    raise ApiError(400, "Bad Request", "X-HTTP-Method-Override is only accepted as PUT on a session timer resource.", "invalid-method-override")
            _check_accept(environ) if method != "OPTIONS" else None
            response = _dispatch(environ, method, path)
    except ApiError as exc:
        response = _json_error(exc)
    except Exception:
        # Do not leak tokens, tracebacks or internal implementation details.
        response = _json_error(ApiError(500, "Internal Server Error", "An unexpected error occurred.", "internal-error"))

    if response.status == 429 and retry_after is None:
        retry_after = 60
    status, headers, body = _finalize(response, environ, limit, remaining, retry_after if response.status == 429 else None)
    start_response(status, headers)
    return [body] if body else []


def main() -> None:
    host = os.getenv("EMS_SERVICE_HOST", "127.0.0.1")
    port = int(os.getenv("EMS_SERVICE_PORT", "8000"))
    with make_server(host, port, application) as server:
        print(f"EMS Online Examination Service listening on http://{host}:{port}")
        print("Configure EMS_AUTH_SERVICE_URL and EMS_EXAM_SCHEDULE_SERVICE_URL for the dependency endpoints.")
        server.serve_forever()


if __name__ == "__main__":
    main()
