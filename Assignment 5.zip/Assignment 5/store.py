"""In-process demonstration store; only owns exam_sessions and session_timers."""
from __future__ import annotations

import hashlib
import json
import threading
from typing import Callable
from models import ExamSession, utc_now


class IdempotencyConflict(Exception):
    pass


class SessionStore:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._sessions: dict[str, ExamSession] = {}
        self._keys: dict[tuple[str, str], tuple[str, str]] = {}
        self._next_internal_id = 1

    @staticmethod
    def fingerprint(payload: dict) -> str:
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(raw).hexdigest()

    def idempotent_session(self, user_id: str, key: str, fingerprint: str) -> ExamSession | None:
        with self._lock:
            entry = self._keys.get((user_id, key))
            if entry is None:
                return None
            previous_fingerprint, session_id = entry
            if previous_fingerprint != fingerprint:
                raise IdempotencyConflict("This Idempotency-Key was already used with a different request.")
            return self._sessions[session_id]

    def create_session_idempotent(
        self,
        factory: Callable[[int], ExamSession],
        user_id: str,
        key: str,
        fingerprint: str,
    ) -> tuple[ExamSession, bool]:
        with self._lock:
            entry = self._keys.get((user_id, key))
            if entry is not None:
                old_fingerprint, session_id = entry
                if old_fingerprint != fingerprint:
                    raise IdempotencyConflict("This Idempotency-Key was already used with a different request.")
                return self._sessions[session_id], False
            internal_id = self._next_internal_id
            self._next_internal_id += 1
            session = factory(internal_id)
            self._sessions[session.session_id] = session
            self._keys[(user_id, key)] = (fingerprint, session.session_id)
            return session, True

    def get(self, session_id: str) -> ExamSession | None:
        with self._lock:
            return self._sessions.get(session_id)

    def list_sessions(self) -> list[ExamSession]:
        with self._lock:
            return list(self._sessions.values())

    def update_timer(self, session_id: str, duration_seconds: int, remaining_seconds: int, paused_seconds: int) -> ExamSession:
        with self._lock:
            session = self._sessions[session_id]
            session.timer.duration_seconds = duration_seconds
            session.timer.remaining_seconds = remaining_seconds
            session.timer.paused_seconds = paused_seconds
            session.timer.updated_at = utc_now()
            # Changing the timer changes its ETag and the parent session ETag too.
            return session

    def terminate(self, session_id: str) -> ExamSession | None:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                return None
            # Repeating the termination request does not change state again.
            if session.session_status == "active":
                session.session_status = "terminated"
                session.termination_at = utc_now()
                session.timer.remaining_seconds = 0
                session.timer.updated_at = session.termination_at
            return session

    def reset(self) -> None:
        with self._lock:
            self._sessions.clear()
            self._keys.clear()
            self._next_internal_id = 1


store = SessionStore()
