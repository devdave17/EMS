# Campus Exam Management System – Brief

Our project is an **Exam Management System (EMS)** designed to manage online examinations. The main objective is to streamline the examination process for both students and the personnel conducting the exams. 

Through this system, students can check their exam schedules, attend exams online, submit their answers, and view their results. The system also features a robust monitoring facility to help proctors identify suspicious activities during an ongoing exam.

## User Roles

There are four primary types of users in this system, each with specific permissions and responsibilities:

*   **Students:** Use the system to check their schedules, attend exams, and view their final results.
*   **Proctors:** Monitor students during the examination and review automated alerts if any suspicious activity is detected.
*   **Admins:** Manage user accounts, exam schedules, question papers, and system-wide monitoring settings.
*   **Exam Authorities:** Utilize the system primarily to access examination records, overall statistics, and detailed reports.

---

## System Architecture: Nouns & Verbs

To understand how the system communicates and handles data, we can break it down into nouns (resources/services) and verbs (actions/contracts).

### Nouns (Things and Services)

The main nouns in our system represent the objects and services required to perform various examination-related tasks.

**Objects / Resources**
These are the entities that contain information the system needs to store or manage:
*   Users & Students
*   Exams & Exam Schedules
*   Question Papers & Questions
*   Exam Attempts & Answers
*   Results
*   Monitoring Records & Malpractice Alerts

> *Example:* An **exam** resource contains details such as its title, date, time, duration, and total marks. An **exam attempt** resource contains a student's answers and their submission status.

**Services**
These handle particular modular tasks within the system:
*   **Authentication Service:** Verifies user login credentials.
*   **Exam Management Service:** Oversees the creation and scheduling of exams.
*   **Question Paper Management Service:** Handles the storage and organization of test questions.
*   **Examination Service:** Handles active exam activities, such as retrieving questions and submitting answers.
*   **Monitoring Service:** Tracks user behavior during active exams for integrity.
*   **Report Generation Service:** Compiles data into digestible statistics and records.

### Verbs (Actions, Tasks, and Contracts)

The verbs represent the actions performed by users or automated by the system. 

**Key Actions:**
*   Log in / Authenticate
*   Create an exam / Update a schedule
*   Manage questions
*   Start an exam / Retrieve questions
*   Save answers / Submit an exam
*   Monitor activity / Generate alerts / Review evidence
*   Generate reports / View results

**Web Service Contracts**
These actions are connected to Web Services through **request and response contracts**:
*   *Schedule Request:* When a student requests an exam schedule, the client sends a request to the server, and the server returns the available exam details.
*   *Exam Submission:* When a student submits answers, the system receives the answers, stores the submission, and returns a confirmation receipt.
*   *Alert Retrieval:* A proctor can request malpractice alerts and receive the related evidence and information from the server.

---

### Conclusion

Overall, the Exam Management System is divided into distinct resources and services, with each service providing specific operations. This modular approach makes it easier to understand how the system's different components communicate and how Web Services can be effectively used to handle all examination-related activities.