#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
free_port() {
  python - <<'PY'
import socket
s = socket.socket()
s.bind(("127.0.0.1", 0))
print(s.getsockname()[1])
s.close()
PY
}
DEP_PORT="$(free_port)"
APP_PORT="$(free_port)"
export EMS_AUTH_SERVICE_URL="http://127.0.0.1:${DEP_PORT}"
export EMS_EXAM_SCHEDULE_SERVICE_URL="http://127.0.0.1:${DEP_PORT}"
export EMS_SERVICE_PORT="$APP_PORT"
export EMS_HTTP_MAX_ATTEMPTS=3
python mock_dependencies.py --port "$DEP_PORT" > /tmp/ems4-mock.log 2>&1 &
MOCK_PID=$!
python app.py > /tmp/ems4-app.log 2>&1 &
APP_PID=$!
cleanup() {
  kill "$APP_PID" "$MOCK_PID" 2>/dev/null || true
  wait "$APP_PID" "$MOCK_PID" 2>/dev/null || true
}
trap cleanup EXIT
BASE="http://127.0.0.1:${APP_PORT}"
for _ in $(seq 1 50); do
  if curl -s -o /dev/null "$BASE/not-a-route"; then break; fi
  sleep 0.1
done
EXAM_ID="aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
UNKNOWN_ID="ffffffff-ffff-4fff-8fff-ffffffffffff"

{
  echo "EMS Assignment 4 curl transcript (local mock dependencies; no live EMS backend)"
  echo "Endpoint: $BASE"
  echo
  printf "$ curl -i -X POST '%s/exam-sessions' -H 'Authorization: Bearer student-token' -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-create-1' -d '{\"exam_id\":\"%s\"}'\n" "$BASE" "$EXAM_ID"
  CREATE_OUT="$(curl -si -X POST "$BASE/exam-sessions" \
    -H 'Authorization: Bearer student-token' \
    -H 'Content-Type: application/json' \
    -H 'Idempotency-Key: demo-create-1' \
    -d "{\"exam_id\":\"$EXAM_ID\"}")"
  printf '%s\n\n' "$CREATE_OUT"
  LOCATION="$(printf '%s\n' "$CREATE_OUT" | awk 'BEGIN{IGNORECASE=1} /^Location:/ {gsub("\r", "", $2); print $2; exit}')"
  SESSION_ID="${LOCATION##*/}"
  if [[ -z "$SESSION_ID" || "$SESSION_ID" == "$LOCATION" ]]; then
    echo "Failed to read the Location header from create response." >&2
    exit 1
  fi

  printf "$ curl -i -X POST '%s/exam-sessions' -H 'Authorization: Bearer student-token' -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-create-1' -d '{\"exam_id\":\"%s\"}' (repeat same request)\n" "$BASE" "$EXAM_ID"
  curl -si -X POST "$BASE/exam-sessions" \
    -H 'Authorization: Bearer student-token' \
    -H 'Content-Type: application/json' \
    -H 'Idempotency-Key: demo-create-1' \
    -d "{\"exam_id\":\"$EXAM_ID\"}"
  echo; echo

  printf "$ curl -i -X POST '%s/exam-sessions' -H 'Authorization: Bearer student-token' -H 'Content-Type: application/json' -H 'Idempotency-Key: demo-malformed-1' -d '{\"exam_id\":\"not-a-uuid\"}'\n" "$BASE"
  curl -si -X POST "$BASE/exam-sessions" \
    -H 'Authorization: Bearer student-token' \
    -H 'Content-Type: application/json' \
    -H 'Idempotency-Key: demo-malformed-1' \
    -d '{"exam_id":"not-a-uuid"}'
  echo; echo

  printf "$ curl -i '%s/exam-sessions/%s' -H 'Authorization: Bearer student-token'\n" "$BASE" "$UNKNOWN_ID"
  curl -si "$BASE/exam-sessions/$UNKNOWN_ID" -H 'Authorization: Bearer student-token'
  echo; echo

  printf "$ curl -i -X POST '%s/exam-sessions/%s/termination' -H 'Authorization: Bearer proctor-token' -H 'Content-Type: application/json' -d '{\"confirm\":true}' (proctor terminates active session)\n" "$BASE" "$SESSION_ID"
  curl -si -X POST "$BASE/exam-sessions/$SESSION_ID/termination" \
    -H 'Authorization: Bearer proctor-token' \
    -H 'Content-Type: application/json' -d '{"confirm":true}'
  echo; echo

  printf "$ curl -i -X POST '%s/exam-sessions/%s/termination' -H 'Authorization: Bearer proctor-token' -H 'Content-Type: application/json' -d '{\"confirm\":true}' again (state conflict)\n" "$BASE" "$SESSION_ID"
  curl -si -X POST "$BASE/exam-sessions/$SESSION_ID/termination" \
    -H 'Authorization: Bearer proctor-token' \
    -H 'Content-Type: application/json' -d '{"confirm":true}'
  echo
} > curl-transcript.txt
