"""WSGI application for the EMS Online Examination Service.

Run locally with:
    python app.py
The service dependencies are configured with EMS_AUTH_SERVICE_URL and
EMS_EXAM_SCHEDULE_SERVICE_URL. Do not put those URLs in source code.
"""
from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from io import BytesIO
from urllib.parse import parse_qs
from uuid import UUID, uuid4
from wsgiref.simple_server import make_server
from typing import Any, Callable

from clients import (
    UpstreamAuthenticationFailed,
    UpstreamBadResponse,
    UpstreamExamNotFound,
    UpstreamForbidden,
    UpstreamUnavailable,
    fetch_exam_schedule,
    verify_token,
)
from errors import ApiError, problem
from models import ExamSession, SessionTimer, utc_now, validate
from store import store

STAFF_ROLES = {"admin", "proctor", "exam_authority"}
ALLOWED_SESSION_FILTERS = {"active", "submitted", "terminated"}
MAX_BODY_BYTES = 64 * 1024


def _json_response(start_response: Callable, status: int, payload: dict | list, headers: list[tuple[str, str]] | None = None, problem_body: bool = False) -> list[bytes]:
    raw = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    response_headers = [
        ("Content-Type", "application/problem+json" if problem_body else "application/json"),
        ("Content-Length", str(len(raw))),
        ("Cache-Control", "no-store"),
    ]
    if headers:
        response_headers.extend(headers)
    start_response(f"{status} {_status_text(status)}", response_headers)
    return [raw]


def _status_text(status: int) -> str:
    return {
        200: "OK", 201: "Created", 400: "Bad Request", 401: "Unauthorized",
        403: "Forbidden", 404: "Not Found", 409: "Conflict", 422: "Unprocessable Entity",
        500: "Internal Server Error", 502: "Bad Gateway", 503: "Service Unavailable",
    }.get(status, "Response")


def _error(start_response: Callable, error: ApiError) -> list[bytes]:
    return _json_response(start_response, error.status, problem(error.status, error.title, error.detail, error.slug), problem_body=True)


def _parse_body(environ: dict[str, Any]) -> dict[str, Any]:
    content_type = environ.get("CONTENT_TYPE", "").split(";", 1)[0].strip().lower()
    if content_type != "application/json":
        raise ApiError(400, "Bad Request", "Content-Type must be application/json.", "invalid-content-type")
    try:
        length = int(environ.get("CONTENT_LENGTH") or "0")
    except ValueError as exc:
        raise ApiError(400, "Bad Request", "Content-Length is invalid.", "malformed-request") from exc
    if length < 0 or length > MAX_BODY_BYTES:
        raise ApiError(400, "Bad Request", "Request body is too large or has an invalid length.", "malformed-request")
    raw = environ["wsgi.input"].read(length) if length else b""
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ApiError(400, "Bad Request", "Request body must contain valid JSON.", "malformed-request") from exc
    if not isinstance(payload, dict):
        raise ApiError(400, "Bad Request", "Request body must be a JSON object.", "malformed-request")
    return payload


def _validate_body(payload: dict[str, Any], expected_fields: set[str]) -> None:
    try:
        validate(payload, expected_fields)
    except ValueError as exc:
        raise ApiError(400, "Bad Request", str(exc), "invalid-request-shape") from exc


def _valid_uuid(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ApiError(400, "Bad Request", f"{field} must be a UUID string.", "invalid-identifier")
    try:
        return str(UUID(value))
    except (ValueError, TypeError, AttributeError) as exc:
        raise ApiError(400, "Bad Request", f"{field} must be a valid UUID.", "invalid-identifier") from exc


def _bearer_token(environ: dict[str, Any]) -> str:
    header = environ.get("HTTP_AUTHORIZATION", "")
    match = re.fullmatch(r"Bearer\s+([^\s]+)", header.strip(), flags=re.IGNORECASE)
    if not match:
        raise ApiError(401, "Unauthorized", "A valid Bearer access token is required.", "authentication-required")
    return match.group(1)


def _principal(environ: dict[str, Any]) -> dict[str, Any]:
    token = _bearer_token(environ)
    try:
        return verify_token(token)
    except UpstreamAuthenticationFailed as exc:
        raise ApiError(401, "Unauthorized", str(exc), "invalid-token") from exc
    except UpstreamForbidden as exc:
        raise ApiError(403, "Forbidden", str(exc), "access-denied") from exc
    except UpstreamUnavailable as exc:
        raise ApiError(503, "Service Unavailable", "Authentication cannot be checked right now. Please retry later.", "authentication-unavailable") from exc
    except UpstreamBadResponse as exc:
        raise ApiError(502, "Bad Gateway", "Authentication Service returned an invalid response.", "invalid-dependency-response") from exc


def _require_role(principal: dict[str, Any], allowed_roles: set[str]) -> None:
    roles = set(principal.get("roles", []))
    if not roles.intersection(allowed_roles):
        raise ApiError(403, "Forbidden", "Your role is not allowed to perform this operation.", "role-not-permitted")


def _can_view(principal: dict[str, Any], session: ExamSession) -> bool:
    return session.student_user_id == principal["user_id"] or bool(set(principal["roles"]).intersection(STAFF_ROLES))


def _schedule_for_start(exam_id: str) -> dict[str, Any]:
    try:
        schedule = fetch_exam_schedule(exam_id)
    except UpstreamExamNotFound as exc:
        raise ApiError(422, "Exam cannot be started", "The requested examination is not available in the schedule.", "exam-not-available") from exc
    except UpstreamUnavailable as exc:
        raise ApiError(503, "Service Unavailable", "Exam Schedule Management is temporarily unavailable. Please retry later.", "schedule-service-unavailable") from exc
    except UpstreamBadResponse as exc:
        raise ApiError(502, "Bad Gateway", "Exam Schedule Management returned an invalid response.", "invalid-dependency-response") from exc

    now = utc_now()
    if schedule["status"].lower() not in {"scheduled", "published"}:
        raise ApiError(422, "Exam cannot be started", "The examination is not in a startable state.", "exam-not-startable")
    if now < schedule["start_at"]:
        raise ApiError(422, "Exam has not started", "The examination start time has not arrived.", "exam-not-open")
    if now >= schedule["end_at"]:
        raise ApiError(422, "Exam has ended", "The examination end time has passed.", "exam-window-closed")
    return schedule


def _parse_query(environ: dict[str, Any]) -> dict[str, str]:
    query = parse_qs(environ.get("QUERY_STRING", ""), keep_blank_values=True, strict_parsing=False)
    allowed = {"exam_id", "status"}
    unknown = set(query) - allowed
    if unknown:
        raise ApiError(400, "Bad Request", "Unsupported query parameter(s): " + ", ".join(sorted(unknown)) + ".", "invalid-query")
    result: dict[str, str] = {}
    for key, values in query.items():
        if len(values) != 1 or not values[0].strip():
            raise ApiError(400, "Bad Request", f"Query parameter {key} must appear once and must not be empty.", "invalid-query")
        result[key] = values[0].strip()
    if "exam_id" in result:
        result["exam_id"] = _valid_uuid(result["exam_id"], "exam_id")
    if "status" in result and result["status"] not in ALLOWED_SESSION_FILTERS:
        raise ApiError(400, "Bad Request", "status must be active, submitted, or terminated.", "invalid-query")
    return result


def _start_session(environ: dict[str, Any], start_response: Callable) -> list[bytes]:
    payload = _parse_body(environ)  # Validate the whole body before reading fields.
    _validate_body(payload, {"exam_id"})
    exam_id = _valid_uuid(payload["exam_id"], "exam_id")
    idempotency_key = environ.get("HTTP_IDEMPOTENCY_KEY", "").strip()
    if not idempotency_key or len(idempotency_key) > 200:
        raise ApiError(400, "Bad Request", "Idempotency-Key is required and must be at most 200 characters.", "idempotency-key-required")

    principal = _principal(environ)
    _require_role(principal, {"student"})
    user_id = principal["user_id"]
    request_fingerprint = store.fingerprint({"exam_id": exam_id})

    # Fast path ensures a normal repeated request does not call Exam Schedule
    # Management or create another session. Authentication is still checked.
    existing = store.idempotent_session(user_id, idempotency_key, request_fingerprint)
    if existing is not None:
        return _json_response(start_response, 201, existing.as_json(), [("Location", f"/exam-sessions/{existing.session_id}")])

    schedule = _schedule_for_start(exam_id)
    now = utc_now()
    expires_at = min(now + timedelta(minutes=schedule["duration_minutes"]), schedule["end_at"])

    def factory(internal_id: int) -> ExamSession:
        session_id = str(uuid4())
        timer_id = str(uuid4())
        duration_seconds = max(0, int((expires_at - now).total_seconds()))
        timer = SessionTimer(
            timer_id=timer_id,
            session_id=session_id,
            started_at=now,
            duration_seconds=duration_seconds,
            remaining_seconds=duration_seconds,
            paused_seconds=0,
            updated_at=now,
        )
        return ExamSession(
            session_id=session_id,
            exam_id=exam_id,
            student_user_id=user_id,
            session_status="active",
            started_at=now,
            expires_at=expires_at,
            submitted_at=None,
            timer=timer,
            internal_id=internal_id,
            idempotency_key=idempotency_key,
        )

    session, _created_now = store.create_session_idempotent(factory, user_id, idempotency_key, request_fingerprint)
    return _json_response(start_response, 201, session.as_json(), [("Location", f"/exam-sessions/{session.session_id}")])


def _get_session(environ: dict[str, Any], start_response: Callable, raw_session_id: str) -> list[bytes]:
    session_id = _valid_uuid(raw_session_id, "session_id")
    principal = _principal(environ)
    session = store.get(session_id)
    if session is None:
        raise ApiError(404, "Not Found", "No examination session exists with that identifier.", "session-not-found")
    if not _can_view(principal, session):
        raise ApiError(403, "Forbidden", "You may only view your own sessions unless you have an authorized staff role.", "access-denied")
    return _json_response(start_response, 200, session.as_json())


def _list_sessions(environ: dict[str, Any], start_response: Callable) -> list[bytes]:
    principal = _principal(environ)
    filters = _parse_query(environ)
    sessions = store.list_sessions()
    if not set(principal["roles"]).intersection(STAFF_ROLES):
        sessions = [session for session in sessions if session.student_user_id == principal["user_id"]]
    if "exam_id" in filters:
        sessions = [session for session in sessions if session.exam_id == filters["exam_id"]]
    if "status" in filters:
        sessions = [session for session in sessions if session.session_status == filters["status"]]
    sessions.sort(key=lambda item: item.started_at, reverse=True)
    return _json_response(start_response, 200, {"items": [item.as_json() for item in sessions], "count": len(sessions)})


def _terminate_session(environ: dict[str, Any], start_response: Callable, raw_session_id: str) -> list[bytes]:
    session_id = _valid_uuid(raw_session_id, "session_id")
    payload = _parse_body(environ)
    _validate_body(payload, {"confirm"})
    if payload["confirm"] is not True:
        raise ApiError(400, "Bad Request", "confirm must be true to terminate a session.", "termination-not-confirmed")
    principal = _principal(environ)
    _require_role(principal, STAFF_ROLES)
    session = store.terminate(session_id)
    return _json_response(start_response, 200, session.as_json())


def application(environ: dict[str, Any], start_response: Callable) -> list[bytes]:
    method = environ.get("REQUEST_METHOD", "GET").upper()
    path = environ.get("PATH_INFO", "/")
    try:
        if path == "/exam-sessions" and method == "POST":
            return _start_session(environ, start_response)
        if path == "/exam-sessions" and method == "GET":
            return _list_sessions(environ, start_response)
        match = re.fullmatch(r"/exam-sessions/([^/]+)", path)
        if match and method == "GET":
            return _get_session(environ, start_response, match.group(1))
        match = re.fullmatch(r"/exam-sessions/([^/]+)/termination", path)
        if match and method == "POST":
            return _terminate_session(environ, start_response, match.group(1))
        return _error(start_response, ApiError(404, "Not Found", "The requested endpoint does not exist.", "endpoint-not-found"))
    except ApiError as exc:
        return _error(start_response, exc)
    except Exception:
        # Do not leak stack traces, tokens, or internal implementation details.
        return _error(start_response, ApiError(500, "Internal Server Error", "An unexpected error occurred.", "internal-error"))


def main() -> None:
    host = "127.0.0.1"
    port = int(__import__("os").getenv("EMS_SERVICE_PORT", "8000"))
    with make_server(host, port, application) as server:
        print(f"EMS Online Examination Service listening on http://{host}:{port}")
        print("Set EMS_AUTH_SERVICE_URL and EMS_EXAM_SCHEDULE_SERVICE_URL before sending requests.")
        server.serve_forever()


if __name__ == "__main__":
    main()
