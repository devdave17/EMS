"""Development-only mock for the EMS dependencies used by the curl demo/tests.

It is not a real Authentication or Exam Schedule service. Do not deploy it.
"""
from __future__ import annotations
import argparse
import json
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

STUDENT_ID = "11111111-1111-4111-8111-111111111111"
PROCTOR_ID = "22222222-2222-4222-8222-222222222222"
NOT_FOUND_EXAM_ID = "00000000-0000-4000-8000-000000000404"
CLOSED_EXAM_ID = "dddddddd-dddd-4ddd-8ddd-dddddddddddd"

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        return
    def send_json(self, status, obj):
        payload = json.dumps(obj).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        try:
            body = json.loads(self.rfile.read(length).decode())
        except Exception:
            self.send_json(400, {"valid": False})
            return
        if self.path != "/token-verifications":
            self.send_json(404, {"detail": "not found"})
            return
        token = body.get("token")
        if token == "student-token":
            self.send_json(200, {"valid": True, "user_id": STUDENT_ID, "roles": ["student"]})
        elif token == "proctor-token":
            self.send_json(200, {"valid": True, "user_id": PROCTOR_ID, "roles": ["proctor"]})
        elif token == "admin-token":
            self.send_json(200, {"valid": True, "user_id": PROCTOR_ID, "roles": ["admin"]})
        else:
            self.send_json(401, {"valid": False})
    def do_GET(self):
        if not self.path.startswith("/exams/"):
            self.send_json(404, {"detail": "not found"})
            return
        exam_id = self.path.rsplit("/", 1)[-1]
        if exam_id == NOT_FOUND_EXAM_ID:
            self.send_json(404, {"detail": "exam not found"})
            return
        now = datetime.now(timezone.utc)
        if exam_id == CLOSED_EXAM_ID:
            start_at, end_at, status = now - timedelta(hours=2), now - timedelta(minutes=1), "closed"
        else:
            start_at, end_at, status = now - timedelta(minutes=5), now + timedelta(hours=2), "scheduled"
        self.send_json(200, {
            "exam_id": exam_id,
            "title": "EMS design-time mock exam",
            "start_at": start_at.isoformat().replace("+00:00", "Z"),
            "end_at": end_at.isoformat().replace("+00:00", "Z"),
            "duration_minutes": 120,
            "status": status,
        })

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8101)
    args = parser.parse_args()
    with ThreadingHTTPServer((args.host, args.port), Handler) as server:
        print(f"Design-time EMS dependency mock on http://{args.host}:{args.port}")
        server.serve_forever()

if __name__ == "__main__":
    main()
