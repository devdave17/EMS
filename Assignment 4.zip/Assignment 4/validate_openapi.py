"""Local structural validation for the OpenAPI document.

It uses FastAPI's installed OpenAPI/Pydantic models when available and checks
all local $ref links, paths, schemas, documented responses, and reusable body
schemas. This is a design-time structural check, not a substitute for Swagger
Editor/openapi-spec-validator in an online environment.
"""
from __future__ import annotations
import sys
from pathlib import Path
import yaml

path = Path(__file__).with_name("openapi.yaml")
spec = yaml.safe_load(path.read_text(encoding="utf-8"))
errors: list[str] = []
if spec.get("openapi") != "3.0.3":
    errors.append("openapi must be 3.0.3")
if not all(k in spec for k in ("info", "servers", "paths", "components")):
    errors.append("missing required top-level field")

schemas = spec.get("components", {}).get("schemas", {})
def resolve_ref(ref: str):
    if not ref.startswith("#/components/"):
        errors.append(f"external/unsupported reference: {ref}")
        return None
    obj = spec
    for part in ref[2:].split("/"):
        obj = obj.get(part) if isinstance(obj, dict) else None
        if obj is None:
            errors.append(f"unresolved $ref: {ref}")
            return None
    return obj

def walk_refs(obj):
    if isinstance(obj, dict):
        if "$ref" in obj:
            resolve_ref(obj["$ref"])
        for value in obj.values():
            walk_refs(value)
    elif isinstance(obj, list):
        for value in obj:
            walk_refs(value)

walk_refs(spec)
if not schemas:
    errors.append("components.schemas is empty")

op_count = 0
for path_name, path_item in spec.get("paths", {}).items():
    if not path_name.startswith("/"):
        errors.append(f"path must start with /: {path_name}")
    for method, operation in path_item.items():
        if method.lower() not in {"get", "post", "put", "patch", "delete", "options", "head", "trace"}:
            continue
        op_count += 1
        if not operation.get("operationId"):
            errors.append(f"{method.upper()} {path_name} missing operationId")
        if not operation.get("responses") or len(operation["responses"]) < 2:
            errors.append(f"{method.upper()} {path_name} must document at least two responses")
        if method.lower() not in {"get", "head", "delete", "options"} and not ("requestBody" in operation or operation.get("parameters")):
            errors.append(f"{method.upper()} {path_name} missing requestBody/parameters")
        # Check request and response body schemas are references rather than inline copies.
        rb = operation.get("requestBody", {})
        for media in rb.get("content", {}).values():
            schema = media.get("schema", {})
            if schema and "$ref" not in schema:
                errors.append(f"{method.upper()} {path_name} has inline request schema")
        for code, response in operation.get("responses", {}).items():
            resolved_response = resolve_ref(response["$ref"]) if "$ref" in response else response
            for media in (resolved_response or {}).get("content", {}).values():
                schema = media.get("schema", {})
                if schema and "$ref" not in schema:
                    errors.append(f"{method.upper()} {path_name} response {code} has inline schema")
if op_count < 4:
    errors.append("fewer than four operations found")

# Prefer the official validator when installed. In an offline environment, use
# the installed OpenAPI/Pydantic model as a second structural check instead.
validator_method = "local structural checks"
try:
    from openapi_spec_validator import validate as official_validate
    official_validate(spec)
    validator_method = "openapi-spec-validator"
except ImportError:
    try:
        from fastapi.openapi.models import OpenAPI
        OpenAPI.model_validate(spec)
        validator_method = "FastAPI OpenAPI/Pydantic model (offline fallback)"
    except Exception as exc:
        errors.append(f"OpenAPI model validation failed: {exc}")
except Exception as exc:
    errors.append(f"openapi-spec-validator failed: {exc}")

if errors:
    print(f"OpenAPI validation: FAILED ({len(errors)} error(s))")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)
print("OpenAPI validation: PASS")
print(f" - Validator: {validator_method}")
print(f" - OpenAPI version: {spec['openapi']}")
print(f" - Operations checked: {op_count}")
print(f" - Reusable schemas: {len(schemas)}")
print(" - Local $ref targets: all resolved")
print(" - Request/response schemas: referenced from components.schemas")
print(" - All operations document at least two responses")
