from __future__ import annotations

import json
import os
import threading
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import BytesIO
from urllib.parse import urlsplit

import pytest

import app
import clients
from store import store

STUDENT_ID = "11111111-1111-4111-8111-111111111111"
PROCTOR_ID = "22222222-2222-4222-8222-222222222222"
EXAM_ID = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
UNKNOWN_SESSION = "ffffffff-ffff-4fff-8fff-ffffffffffff"
CLOSED_EXAM_ID = "dddddddd-dddd-4ddd-8ddd-dddddddddddd"
FAIL_ONCE_EXAM_ID = "eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee"
NOT_FOUND_EXAM_ID = "00000000-0000-4000-8000-000000000404"


class DependencyHandler(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        return

    def _send(self, status: int, payload: dict) -> None:
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        self.server.counts[self.path] = self.server.counts.get(self.path, 0) + 1
        length = int(self.headers.get("Content-Length", "0"))
        try:
            body = json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            self._send(400, {"detail": "bad json"})
            return
        if self.path == "/token-verifications":
            token = body.get("token")
            if not hasattr(self.server, "auth_idempotency_keys"):
                self.server.auth_idempotency_keys = []
            self.server.auth_idempotency_keys.append(self.headers.get("Idempotency-Key"))
            if token == "retry-auth-token" and self.server.counts[self.path] == 1:
                self._send(503, {"detail": "temporary authentication problem"})
                return
            if token in {"student-token", "retry-auth-token"}:
                self._send(200, {"valid": True, "user_id": STUDENT_ID, "roles": ["student"]})
            elif token == "proctor-token":
                self._send(200, {"valid": True, "user_id": PROCTOR_ID, "roles": ["proctor"]})
            elif token == "admin-token":
                self._send(200, {"valid": True, "user_id": PROCTOR_ID, "roles": ["admin"]})
            else:
                self._send(401, {"valid": False})
            return
        self._send(404, {"detail": "not found"})

    def do_GET(self):
        self.server.counts[self.path] = self.server.counts.get(self.path, 0) + 1
        prefix = "/exams/"
        if not self.path.startswith(prefix):
            self._send(404, {"detail": "not found"})
            return
        exam_id = self.path[len(prefix):]
        if exam_id == NOT_FOUND_EXAM_ID:
            self._send(404, {"detail": "exam not found"})
            return
        if exam_id == FAIL_ONCE_EXAM_ID and self.server.counts[self.path] == 1:
            self._send(503, {"detail": "temporary problem"})
            return
        now = datetime.now(timezone.utc)
        if exam_id == CLOSED_EXAM_ID:
            start_at = now - timedelta(hours=2)
            end_at = now - timedelta(minutes=1)
            status = "closed"
        else:
            start_at = now - timedelta(minutes=5)
            end_at = now + timedelta(hours=2)
            status = "scheduled"
        self._send(200, {
            "exam_id": exam_id,
            "title": "Midterm Examination",
            "start_at": start_at.isoformat().replace("+00:00", "Z"),
            "end_at": end_at.isoformat().replace("+00:00", "Z"),
            "duration_minutes": 120,
            "status": status,
        })


@pytest.fixture(autouse=True)
def reset_store_and_dependencies(monkeypatch):
    with store._lock:
        store._sessions.clear()
        store._idempotency.clear()
        store._next_internal_id = 1
    server = ThreadingHTTPServer(("127.0.0.1", 0), DependencyHandler)
    server.counts = {}
    server.auth_idempotency_keys = []
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{server.server_address[1]}"
    monkeypatch.setenv("EMS_AUTH_SERVICE_URL", base)
    monkeypatch.setenv("EMS_EXAM_SCHEDULE_SERVICE_URL", base)
    monkeypatch.setenv("EMS_HTTP_MAX_ATTEMPTS", "3")
    monkeypatch.setenv("EMS_HTTP_CONNECT_TIMEOUT", "0.5")
    monkeypatch.setenv("EMS_HTTP_READ_TIMEOUT", "0.5")
    monkeypatch.setattr(clients.time, "sleep", lambda _seconds: None)
    yield server
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)


def call_app(method: str, path: str, *, body=None, raw: bytes | None = None, token="student-token", idempotency_key=None, content_type="application/json"):
    split = urlsplit(path)
    if raw is None:
        raw = b"" if body is None else json.dumps(body).encode("utf-8")
    headers = {"HTTP_AUTHORIZATION": f"Bearer {token}"} if token else {}
    if idempotency_key is not None:
        headers["HTTP_IDEMPOTENCY_KEY"] = idempotency_key
    environ = {
        "REQUEST_METHOD": method,
        "PATH_INFO": split.path,
        "QUERY_STRING": split.query,
        "CONTENT_TYPE": content_type,
        "CONTENT_LENGTH": str(len(raw)),
        "wsgi.input": BytesIO(raw),
        "wsgi.url_scheme": "http",
        "SERVER_NAME": "localhost",
        "SERVER_PORT": "8000",
        "SERVER_PROTOCOL": "HTTP/1.1",
        "wsgi.version": (1, 0),
        "wsgi.errors": BytesIO(),
        "wsgi.multithread": False,
        "wsgi.multiprocess": False,
        "wsgi.run_once": False,
    }
    environ.update(headers)
    captured = {}

    def start_response(status, response_headers, exc_info=None):
        captured["status"] = int(status.split()[0])
        captured["headers"] = dict(response_headers)

    output = b"".join(app.application(environ, start_response))
    captured["body"] = json.loads(output.decode("utf-8")) if output else None
    return captured


def start_session(key="start-1", exam_id=EXAM_ID):
    return call_app("POST", "/exam-sessions", body={"exam_id": exam_id}, idempotency_key=key)


def test_create_returns_201_location_and_hides_internal_fields():
    response = start_session()
    assert response["status"] == 201
    assert response["headers"]["Location"].startswith("/exam-sessions/")
    assert response["body"]["session_status"] == "active"
    assert "student_user_id" not in response["body"]
    assert "internal_id" not in response["body"]
    assert "timer_id" not in response["body"]["timer"]
    assert "token" not in json.dumps(response["body"]).lower()


def test_same_idempotency_key_returns_original_without_rechecking_schedule(reset_store_and_dependencies):
    server = reset_store_and_dependencies
    first = start_session(key="retry-key")
    schedule_path = f"/exams/{EXAM_ID}"
    calls_after_first = server.counts[schedule_path]
    second = start_session(key="retry-key")
    assert first["status"] == second["status"] == 201
    assert first["body"] == second["body"]
    assert first["headers"]["Location"] == second["headers"]["Location"]
    assert server.counts[schedule_path] == calls_after_first
    assert len(store.list_sessions()) == 1


def test_malformed_json_returns_common_problem_shape():
    response = call_app("POST", "/exam-sessions", raw=b'{"exam_id":', idempotency_key="bad-json")
    assert response["status"] == 400
    assert response["headers"]["Content-Type"] == "application/problem+json"
    assert set(response["body"]) == {"type", "title", "status", "detail"}


def test_unknown_session_returns_404():
    response = call_app("GET", f"/exam-sessions/{UNKNOWN_SESSION}")
    assert response["status"] == 404
    assert response["body"]["status"] == 404


def test_state_changing_termination_then_repeat_is_conflict():
    created = start_session()
    session_id = created["body"]["session_id"]
    first = call_app("POST", f"/exam-sessions/{session_id}/termination", body={"confirm": True}, token="proctor-token")
    second = call_app("POST", f"/exam-sessions/{session_id}/termination", body={"confirm": True}, token="proctor-token")
    assert first["status"] == 200
    assert first["body"]["session_status"] == "terminated"
    assert first["body"]["timer"]["remaining_seconds"] == 0
    assert second["status"] == 409
    assert second["body"]["type"].endswith("session-state-conflict")


def test_idempotency_key_reused_with_different_request_is_409(reset_store_and_dependencies):
    first = start_session(key="same-key", exam_id=EXAM_ID)
    other_exam = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb"
    second = start_session(key="same-key", exam_id=other_exam)
    assert first["status"] == 201
    assert second["status"] == 409


def test_dependency_5xx_is_retried_and_succeeds(reset_store_and_dependencies):
    server = reset_store_and_dependencies
    response = start_session(key="retry-5xx", exam_id=FAIL_ONCE_EXAM_ID)
    assert response["status"] == 201
    assert server.counts[f"/exams/{FAIL_ONCE_EXAM_ID}"] == 2


def test_dependency_4xx_is_not_retried_and_maps_to_domain_error(reset_store_and_dependencies):
    server = reset_store_and_dependencies
    response = start_session(key="missing-exam", exam_id=NOT_FOUND_EXAM_ID)
    assert response["status"] == 422
    assert server.counts[f"/exams/{NOT_FOUND_EXAM_ID}"] == 1


def test_bad_token_is_not_retried(reset_store_and_dependencies):
    server = reset_store_and_dependencies
    response = call_app("GET", "/exam-sessions", token="bad-token")
    assert response["status"] == 401
    assert server.counts["/token-verifications"] == 1


def test_student_cannot_terminate_session():
    created = start_session()
    session_id = created["body"]["session_id"]
    response = call_app("POST", f"/exam-sessions/{session_id}/termination", body={"confirm": True}, token="student-token")
    assert response["status"] == 403


def test_retried_verification_post_reuses_idempotency_key(reset_store_and_dependencies):
    server = reset_store_and_dependencies
    response = call_app(
        "POST", "/exam-sessions", body={"exam_id": EXAM_ID},
        token="retry-auth-token", idempotency_key="retry-auth-create",
    )
    assert response["status"] == 201
    assert server.counts["/token-verifications"] == 2
    assert len(server.auth_idempotency_keys) == 2
    assert server.auth_idempotency_keys[0]
    assert server.auth_idempotency_keys[0] == server.auth_idempotency_keys[1]
