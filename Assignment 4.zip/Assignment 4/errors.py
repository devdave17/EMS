"""Consistent problem responses used by every EMS endpoint."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any


@dataclass
class ApiError(Exception):
    status: int
    title: str
    detail: str
    slug: str = "request-error"

    def __str__(self) -> str:
        return self.detail


def problem(status: int, title: str, detail: str, slug: str = "request-error") -> dict[str, Any]:
    return {
        "type": f"https://ems.example/problems/{slug}",
        "title": title,
        "status": status,
        "detail": detail,
    }


def raise_bad_request(detail: str, slug: str = "malformed-request") -> None:
    raise ApiError(400, "Bad Request", detail, slug)
