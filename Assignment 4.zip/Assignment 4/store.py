"""In-process store for the Online Examination Service.

Only exam_sessions and session_timers data is held here. It never imports or
reads another service's store. The dictionaries are allowed for this lab.
"""
from __future__ import annotations

import hashlib
import json
import threading
from datetime import datetime, timezone
from typing import Callable

from models import ExamSession
from errors import ApiError


class Store:
    def __init__(self) -> None:
        self._sessions: dict[str, ExamSession] = {}
        # Keyed by (authenticated user, Idempotency-Key). Values never appear
        # in the public response.
        self._idempotency: dict[tuple[str, str], tuple[str, str]] = {}
        self._lock = threading.RLock()
        self._next_internal_id = 1

    @staticmethod
    def fingerprint(payload: dict) -> str:
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    def idempotent_session(self, user_id: str, key: str, fingerprint: str) -> ExamSession | None:
        with self._lock:
            saved = self._idempotency.get((user_id, key))
            if saved is None:
                return None
            original_fingerprint, session_id = saved
            if original_fingerprint != fingerprint:
                raise ApiError(
                    409,
                    "Idempotency key conflict",
                    "This Idempotency-Key was already used with a different request.",
                    "idempotency-key-conflict",
                )
            # This should never be missing; report a safe server error if the
            # in-memory state becomes inconsistent.
            session = self._sessions.get(session_id)
            if session is None:
                raise ApiError(503, "Service unavailable", "The original result for this request is no longer available.", "idempotency-result-unavailable")
            return session

    def create_session_idempotent(
        self,
        session_factory: Callable[[int], ExamSession],
        user_id: str,
        key: str,
        fingerprint: str,
    ) -> tuple[ExamSession, bool]:
        """Return (session, created_now). Re-check under lock for race safety."""
        with self._lock:
            saved = self._idempotency.get((user_id, key))
            if saved is not None:
                old_fingerprint, old_session_id = saved
                if old_fingerprint != fingerprint:
                    raise ApiError(409, "Idempotency key conflict", "This Idempotency-Key was already used with a different request.", "idempotency-key-conflict")
                return self._sessions[old_session_id], False

            internal_id = self._next_internal_id
            session = session_factory(internal_id)
            self._next_internal_id += 1
            self._sessions[session.session_id] = session
            self._idempotency[(user_id, key)] = (fingerprint, session.session_id)
            return session, True

    def get(self, session_id: str) -> ExamSession | None:
        with self._lock:
            return self._sessions.get(session_id)

    def list_sessions(self) -> list[ExamSession]:
        with self._lock:
            return list(self._sessions.values())

    def terminate(self, session_id: str) -> ExamSession:
        with self._lock:
            session = self._sessions.get(session_id)
            if session is None:
                raise ApiError(404, "Not Found", "No examination session exists with that identifier.", "session-not-found")
            if session.session_status != "active":
                raise ApiError(409, "Session state conflict", "Only an active session can be terminated.", "session-state-conflict")
            now = datetime.now(timezone.utc)
            session.session_status = "terminated"
            session.timer.remaining_seconds = 0
            session.timer.updated_at = now
            return session


store = Store()
