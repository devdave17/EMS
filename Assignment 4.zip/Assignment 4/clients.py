"""HTTP clients for existing EMS service dependencies.

The final EMS service diagram names verifyToken() and fetchExamSchedule(). For
this REST implementation, those operations are exposed by their owning
services through resource-style HTTP adapters:
  EMS_AUTH_SERVICE_URL/token-verifications
  EMS_EXAM_SCHEDULE_SERVICE_URL/exams/{exam_id}
Base URLs are required from the environment; none is hard-coded here.
"""
from __future__ import annotations

import os
import random
import time
from typing import Any
from urllib.parse import urlparse
from uuid import uuid4

import requests

from errors import ApiError
from models import parse_datetime


class UpstreamUnavailable(Exception):
    pass


class UpstreamAuthenticationFailed(Exception):
    pass


class UpstreamForbidden(Exception):
    pass


class UpstreamExamNotFound(Exception):
    pass


class UpstreamBadResponse(Exception):
    pass


def _base_url(env_name: str) -> str:
    value = os.getenv(env_name, "").strip().rstrip("/")
    if not value:
        raise UpstreamUnavailable(f"{env_name} is not configured.")
    parsed = urlparse(value)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise UpstreamUnavailable(f"{env_name} must contain an absolute HTTP(S) URL.")
    return value


def _timeouts() -> tuple[float, float]:
    try:
        connect = float(os.getenv("EMS_HTTP_CONNECT_TIMEOUT", "1.0"))
        read = float(os.getenv("EMS_HTTP_READ_TIMEOUT", "2.0"))
    except ValueError as exc:
        raise UpstreamUnavailable("HTTP timeout configuration is invalid.") from exc
    if connect <= 0 or read <= 0:
        raise UpstreamUnavailable("HTTP timeouts must be greater than zero.")
    return connect, read


def _max_attempts() -> int:
    try:
        attempts = int(os.getenv("EMS_HTTP_MAX_ATTEMPTS", "3"))
    except ValueError:
        attempts = 3
    return min(max(attempts, 1), 5)


def _request_with_retry(method: str, url: str, *, json_body: dict[str, Any] | None = None, extra_headers: dict[str, str] | None = None) -> requests.Response:
    """Retry network errors and 5xx only. Never retry an HTTP 4xx response."""
    max_attempts = _max_attempts()
    timeout = _timeouts()
    last_exception: Exception | None = None
    for attempt in range(max_attempts):
        try:
            request_headers = {"Accept": "application/json", "Content-Type": "application/json"}
            if extra_headers:
                request_headers.update(extra_headers)
            response = requests.request(
                method,
                url,
                json=json_body,
                headers=request_headers,
                timeout=timeout,
            )
            if response.status_code < 500 or attempt == max_attempts - 1:
                return response
            last_exception = UpstreamUnavailable(f"Dependency returned HTTP {response.status_code}.")
        except (requests.Timeout, requests.ConnectionError) as exc:
            last_exception = exc
            if attempt == max_attempts - 1:
                break
        # Exponential backoff (0.1, 0.2, 0.4...) plus positive random jitter.
        # No sleep after the final attempt.
        delay = 0.1 * (2 ** attempt) + random.uniform(0.0, 0.1)
        time.sleep(delay)
    raise UpstreamUnavailable("An EMS dependency did not respond successfully after retries.") from last_exception


def verify_token(token: str) -> dict[str, Any]:
    base = _base_url("EMS_AUTH_SERVICE_URL")
    # The adapter uses POST to create a verification result. Reuse one key for
    # the whole retry sequence so a dependency can deduplicate a repeated call.
    verification_key = str(uuid4())
    response = _request_with_retry(
        "POST",
        f"{base}/token-verifications",
        json_body={"token": token},
        extra_headers={"Idempotency-Key": verification_key},
    )
    if response.status_code == 401:
        raise UpstreamAuthenticationFailed("The access token is invalid or expired.")
    if response.status_code == 403:
        raise UpstreamForbidden("The caller is not permitted to use this service.")
    if response.status_code >= 500:
        raise UpstreamUnavailable("Authentication Service is temporarily unavailable.")
    if response.status_code < 200 or response.status_code >= 300:
        raise UpstreamBadResponse(f"Authentication Service returned unexpected HTTP {response.status_code}.")
    try:
        payload = response.json()
    except ValueError as exc:
        raise UpstreamBadResponse("Authentication Service returned invalid JSON.") from exc
    if not isinstance(payload, dict) or payload.get("valid") is not True:
        raise UpstreamAuthenticationFailed("The access token is invalid or expired.")
    user_id = payload.get("user_id")
    roles = payload.get("roles")
    if not isinstance(user_id, str) or not isinstance(roles, list) or not all(isinstance(role, str) for role in roles):
        raise UpstreamBadResponse("Authentication Service response does not match its contract.")
    try:
        from uuid import UUID
        UUID(user_id)
    except (ValueError, TypeError) as exc:
        raise UpstreamBadResponse("Authentication Service returned an invalid user identifier.") from exc
    return {"user_id": user_id, "roles": roles}


def fetch_exam_schedule(exam_id: str) -> dict[str, Any]:
    base = _base_url("EMS_EXAM_SCHEDULE_SERVICE_URL")
    response = _request_with_retry("GET", f"{base}/exams/{exam_id}")
    if response.status_code == 404:
        raise UpstreamExamNotFound("The requested examination does not exist in the schedule.")
    if response.status_code >= 500:
        raise UpstreamUnavailable("Exam Schedule Management is temporarily unavailable.")
    if response.status_code < 200 or response.status_code >= 300:
        raise UpstreamBadResponse(f"Exam Schedule Management returned unexpected HTTP {response.status_code}.")
    try:
        payload = response.json()
        if not isinstance(payload, dict):
            raise ValueError("Expected an object")
        returned_id = payload.get("exam_id")
        if returned_id != exam_id:
            raise ValueError("exam_id does not match the requested exam")
        duration = payload.get("duration_minutes")
        if not isinstance(duration, int) or isinstance(duration, bool) or duration <= 0:
            raise ValueError("duration_minutes must be a positive integer")
        start_at = parse_datetime(payload.get("start_at"), "start_at")
        end_at = parse_datetime(payload.get("end_at"), "end_at")
        if end_at <= start_at:
            raise ValueError("end_at must be after start_at")
        status = payload.get("status")
        if not isinstance(status, str):
            raise ValueError("status must be a string")
    except (ValueError, TypeError, KeyError) as exc:
        raise UpstreamBadResponse("Exam Schedule Management returned data that does not match its contract.") from exc
    return {
        "exam_id": exam_id,
        "start_at": start_at,
        "end_at": end_at,
        "duration_minutes": duration,
        "status": status,
    }
