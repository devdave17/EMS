"""Models for the EMS Online Examination Service.

The stored model follows the final EMS schema's exam_sessions and session_timers
ownership. as_json() is the public API representation and intentionally leaves
out student_user_id, timer_id, and other internal/service-only fields.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any


def validate(payload: Any, expected_fields: set[str]) -> None:
    """Validate a parsed request body before handler code reads its fields.

    This is the application-level validation that replaces the validation the
    earlier XML Schema would have supplied for SOAP requests.
    """
    if not isinstance(payload, dict):
        raise ValueError("Request body must be a JSON object.")
    missing = expected_fields - payload.keys()
    extra = payload.keys() - expected_fields
    details = []
    if missing:
        details.append("missing field(s): " + ", ".join(sorted(missing)))
    if extra:
        details.append("unexpected field(s): " + ", ".join(sorted(extra)))
    if details:
        raise ValueError("Request body has " + " and ".join(details) + ".")


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_utc(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass
class SessionTimer:
    timer_id: str
    session_id: str
    started_at: datetime
    duration_seconds: int
    remaining_seconds: int
    paused_seconds: int
    updated_at: datetime

    def as_json(self) -> dict[str, Any]:
        # timer_id and session_id are internal relationship fields. The client
        # needs timer values, not the timer record's internal identity.
        return {
            "duration_seconds": self.duration_seconds,
            "remaining_seconds": self.remaining_seconds,
            "paused_seconds": self.paused_seconds,
            "updated_at": iso_utc(self.updated_at),
        }


@dataclass
class ExamSession:
    session_id: str                 # public resource identifier from the schema
    exam_id: str                    # public reference to an Exam Schedule resource
    student_user_id: str            # internal FK; never returned to the client
    session_status: str
    started_at: datetime
    expires_at: datetime
    submitted_at: datetime | None
    timer: SessionTimer
    internal_id: int                 # service-only in-memory key, not published
    idempotency_key: str | None = None

    def as_json(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "exam_id": self.exam_id,
            "session_status": self.session_status,
            "started_at": iso_utc(self.started_at),
            "expires_at": iso_utc(self.expires_at),
            "submitted_at": iso_utc(self.submitted_at),
            "timer": self.timer.as_json(),
        }


def parse_datetime(value: Any, field_name: str) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} must be an ISO-8601 date-time string")
    candidate = value.strip()
    if candidate.endswith("Z"):
        candidate = candidate[:-1] + "+00:00"
    try:
        result = datetime.fromisoformat(candidate)
    except ValueError as exc:
        raise ValueError(f"{field_name} must be an ISO-8601 date-time string") from exc
    if result.tzinfo is None:
        raise ValueError(f"{field_name} must include a timezone")
    return result.astimezone(timezone.utc)
