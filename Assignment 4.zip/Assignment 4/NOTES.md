# CS543 Web Services — Assignment 4 (adapted to EMS)

# Project: Exam Management System (EMS)  

# Chosen service: Online Examination Service  

# Name(s): \[Dev Dave, Arjun Bodana, Vikash Kumar, Kuldeep Rout]  

# Roll number(s): \[20251651034, 20251651029, 20251651102, 20251651053]

# > We selected the Online Examination Service because it already exists in the final EMS service design and owns `exam\_sessions` and `session\_timers` in the final schema. Its existing cross-service calls include `verifyToken()` in Authentication and `fetchExamSchedule()` in Exam Schedule Management. This REST version keeps the same data boundary; it does not read another service's store.

# The final diagram explicitly names `validateActiveSession()` and `validateSessionState()` and the outbound calls `verifyToken()` and `fetchExamSchedule()`. The create/read/list/termination REST endpoints below are the resource-oriented interface added for this assignment. They are design additions around the same owned data.

# 

# 

# Part A — Model the service

# 

# A2. Operation-style starting point

# The operations we would first list in an operation-oriented contract are:

# `startExamSession(examId)`

# `getExamSession(sessionId)`

# `listExamSessions(examId, status)`

# `terminateExamSession(sessionId)`

# `validateActiveSession(sessionId)` — existing EMS operation used to check whether an attempt is active.

# For the REST interface, verbs are expressed through HTTP methods and the URLs use nouns/resources.

# 

# A3–A4. Resources and endpoint table

# | Method | URL | What it does | Success code | Failure codes |

# | :--- | :--- | :--- | :--- | :--- |

# | `POST` | `/exam-sessions` | Starts an examination session for the authenticated student. Requires `Idempotency-Key`. | `201 Created` with `Location` | `400`, `401`, `403`, `409`, `422`, `500`, `502`, `503` |

# | `GET` | `/exam-sessions/{session\_id}` | Reads one session the caller is allowed to view. | `200 OK` | `400`, `401`, `403`, `404`, `500`, `502`, `503` |

# | `GET` | `/exam-sessions?exam\_id=...\&status=...` | Returns a filtered list of sessions. Students see their own sessions; authorized staff can see permitted sessions. | `200 OK` | `400`, `401`, `403`, `500`, `502`, `503` |

# | `POST` | `/exam-sessions/{session\_id}/termination` | Terminates an active session. This is the state-changing sub-resource; staff authorization is required. | `200 OK` | `400`, `401`, `403`, `404`, `409`, `500`, `502`, `503` |

# 

# A5. Hard choice (resource mapping)

# Starting an exam is an action, so it was the least natural operation to map to a resource. We rejected `/startExam` because it puts a verb in the URL, and used `POST /exam-sessions` because the request creates a session resource. A client must send an `Idempotency-Key`; if it retries after a timeout with the same key and body, EMS returns the original session rather than creating another one. Termination is represented by the noun sub-resource `/exam-sessions/{session\_id}/termination` so that the lifecycle state change is explicit.

# 

# Part B — Publish the contract

# `openapi.yaml` is written before the handler code and defines the four operations, request/response schemas under `components.schemas`, reusable error responses, security, and all documented status codes. The errors are inside the `service\\tests` folder.

# 

# 

# 

# Part C — Implementation notes

# The service folder follows the required shape: `models.py`, `store.py`, `errors.py`, `app.py`, and `tests/`. Storage is an in-process dictionary for this lab. `models.validate()` is called before the handler reads request fields; `valid\_uuid()` checks identifier format. `as\_json()` is the public representation and omits internal fields such as `student\_user\_id`, `timer\_id`, and `internal\_id`.

# `POST /exam-sessions` returns `201 Created` plus a `Location` header. A repeated request with the same authenticated user, `Idempotency-Key`, and body returns the original response. Reusing the key with a different body returns `409 Conflict`. A missing session returns `404`; a malformed body returns `400`; and a session that has already been terminated returns `409` when termination is requested again.

# 

# Part D — Cross-service call and failure behaviour

# Online Examination calls two existing EMS dependencies through configurable URLs:

# The Authentication Service's existing `verifyToken()` operation is mapped to the resource-style adapter `POST {EMS\_AUTH\_SERVICE\_URL}/token-verifications`.

# The Exam Schedule Management Service's existing `fetchExamSchedule()` operation is mapped to `GET {EMS\_EXAM\_SCHEDULE\_SERVICE\_URL}/exams/{exam\_id}`.

# The final service design names those operations but does not define their HTTP paths or wire formats. The paths and JSON payloads above are the REST adapter contracts assumed for this assignment; the dependency services themselves are not implemented in this folder. The project never imports another service's store.

# `clients.py` obtains dependency base URLs from environment variables, sets connect/read timeouts, and retries network errors or HTTP `5xx` responses with exponential backoff and jitter. It does not retry HTTP `4xx` responses. The token-verification adapter is a POST, so it generates one `Idempotency-Key` and reuses that same key for all retries of that single verification call. Schedule lookup is a `GET`. Creating the exam session itself is also protected by the client's `Idempotency-Key`.

# 

# D3. Fallback choice

# If Authentication is unavailable, the service returns `503` and does not start a session, because it cannot confirm who is making the request. If Exam Schedule Management is unavailable, it also returns `503` and does not guess the exam's time window; allowing a session to start using stale or default dates could let a student enter an exam outside its configured schedule. The client can retry the same request with its original `Idempotency-Key` after the dependency recovers.

# 

# 

# Answers to the five questions

# 

# (1.) WSDL line count versus OpenAPI line count

# Using the EMS SMS-partner WSDL kept in `references/ems-sms-partner.wsdl`, `wc -l` reports 97 lines for the WSDL and 326 lines for `openapi.yaml`, a difference of 229 lines. The OpenAPI file is longer because it documents four REST operations, reusable request/response schemas, security, status codes, and a common error response for each failure path. The WSDL had explicit `wsdl:message`/`wsdl:part` definitions and a SOAP binding with a SOAPAction, credentials header, and SOAP fault binding; an ordinary REST OpenAPI contract does not need those SOAP message/binding declarations. This is the EMS SOAP-partner WSDL available from the earlier exercise; it describes the external SMS partner, not a previous SOAP version of Online Examination itself.

# 

# (2.) SOAP fault converted to an HTTP status and Problem body

# The earlier EMS SMS-partner fault contains:

# ```xml

# <soap:Fault>

# &#x20; <faultcode>soap:Server</faultcode>

# &#x20; <faultstring>SMS provider temporarily unavailable</faultstring>

# &#x20; <detail>

# &#x20;   <tns:SmsPartnerFault>

# &#x20;     <tns:code>PARTNER\\\\\\\_UNAVAILABLE</tns:code>

# &#x20;     <tns:message>Temporary upstream service failure</tns:message>

# &#x20;     <tns:retryable>true</tns:retryable>

# &#x20;   </tns:SmsPartnerFault>

# &#x20; </detail>

# </soap:Fault>

# ```

# At an EMS REST-facing notification boundary, that temporary partner failure should become HTTP `503 Service Unavailable`, for example:

# ```http

# HTTP/1.1 503 Service Unavailable

# Content-Type: application/problem+json

# ```

# ```json

# {

# &#x20; "type": "https://ems.example/problems/notification-unavailable",

# &#x20; "title": "Notification service unavailable",

# &#x20; "status": 503,

# &#x20; "detail": "The notification could not be sent right now. Please try again later."

# }

# ```

# The public message does not expose the partner's fault code or message to a student. This mapping belongs to the SMS/notification boundary; the Online Examination endpoints in this assignment do not themselves send SMS messages. Returning the error inside `200 OK` would tell HTTP clients, proxies, monitoring, and retry logic that the request succeeded even though it failed, so they may not handle the failure properly.

# 

# (3.) Which UDDI moves remain?

# All three ideas still exist, but the UDDI server/protocol does not need to. Publish is handled by putting `openapi.yaml` and service metadata into a service catalogue; find is handled by searching the catalogue for the EMS Online Examination Service; bind is handled by reading the registered endpoint and calling it using the documented OpenAPI contract. A configuration service or environment variable supplies the runtime base URL in this small design, rather than running a UDDI server.

# One modern catalogue record could be:

# ```yaml

# business: Exam Management System (EMS)

# service: Online Examination Service

# version: 1.0.0

# endpoint: http://127.0.0.1:8000  # local demo only;

# contract: openapi.yaml

# contract\_format: OpenAPI 3.0.3

# security: Bearer JWT

# ```

# 

# (4.) What now enforces request validation?

# `models.validate()` is called before the endpoint reads the request object's fields. \_parse\_body()` first checks that the body is valid JSON and an object, while `valid\_uuid()` checks the `exam\_id` format before the schedule service is called. Without these checks, a missing field, unexpected field, or malformed UUID could travel deeper into the code and lead to an incorrect downstream request or invalid session data.

# 

# (5.) Where would I still choose SOAP for EMS?

# I would keep SOAP for the external SMS gateway if that partner requires the `sendSMS` WSDL contract. The specific benefit is contract-level interoperability: the operation, XML body, credentials header, and the structured `SmsPartnerFault` are declared in one contract, so both sides can validate the expected message shape and failure vocabulary. That does not guarantee exactly-once delivery or a completed SMS transaction; the current WSDL also does not, by itself, provide WS-Security message signing. For the internal session, schedule, and monitoring APIs, REST is simpler because the operations are resource-oriented and return normal HTTP status codes.

# Verification record

# The checked local commands and their outputs are included in `openapi-validation.txt`, `pytest-output.txt`, and `curl-transcript.txt`. The tests cover creation with `201` and `Location`, idempotent replay, malformed JSON, missing session, state conflict, rejected credentials without retry, safe retry after an upstream `503`, no retry after an upstream `404`, and reuse of the same idempotency key on a retried verification POST.

