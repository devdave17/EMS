-- ==========================================
-- 1. User Management Service
-- ==========================================
CREATE TABLE UserService_user_profiles (
    user_id UUID PRIMARY KEY,
    full_name VARCHAR(255),
    email VARCHAR(255),
    date_of_birth DATE,
    department VARCHAR(255),
    program VARCHAR(255),
    profile_status VARCHAR(50),
    created_at TIMESTAMP
);

-- ==========================================
-- 2. Authentication Service
-- ==========================================
CREATE TABLE AuthService_auth_roles (
    role_id UUID PRIMARY KEY,
    role_name VARCHAR(50),
    description VARCHAR(255)
);

CREATE TABLE AuthService_auth_credentials (
    credential_id UUID PRIMARY KEY,
    user_id UUID, -- Logical API Link to UserService_user_profiles
    password_hash VARCHAR(255),
    credential_status VARCHAR(50),
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

CREATE TABLE AuthService_user_role_assignments (
    assignment_id UUID PRIMARY KEY,
    user_id UUID, -- Logical API Link to UserService_user_profiles
    role_id UUID,
    assigned_at TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES AuthService_auth_roles(role_id)
);

CREATE TABLE AuthService_auth_tokens (
    token_id UUID PRIMARY KEY,
    user_id UUID, -- Logical API Link to UserService_user_profiles
    jwt_token_hash VARCHAR(255),
    issued_at TIMESTAMP,
    expires_at TIMESTAMP,
    revoked_at TIMESTAMP
);

-- ==========================================
-- 3. Exam Schedule Management
-- ==========================================
CREATE TABLE ScheduleService_exams (
    exam_id UUID PRIMARY KEY,
    title VARCHAR(255),
    start_at TIMESTAMP,
    end_at TIMESTAMP,
    duration_minutes SMALLINT,
    total_marks DECIMAL(7,2),
    status VARCHAR(50),
    created_by_user_id UUID -- Logical API Link to UserService_user_profiles
);

CREATE TABLE ScheduleService_exam_roster (
    roster_entry_id UUID PRIMARY KEY,
    exam_id UUID,
    student_user_id UUID, -- Logical API Link to UserService_user_profiles
    attendance_status VARCHAR(50),
    assigned_at TIMESTAMP,
    FOREIGN KEY (exam_id) REFERENCES ScheduleService_exams(exam_id)
);

-- ==========================================
-- 4. Question Paper Management
-- ==========================================
CREATE TABLE QuestionService_question_banks (
    question_bank_id UUID PRIMARY KEY,
    exam_id UUID, -- Logical API Link to ScheduleService_exams
    title VARCHAR(255),
    version SMALLINT,
    created_at TIMESTAMP
);

CREATE TABLE QuestionService_questions (
    question_id UUID PRIMARY KEY,
    question_bank_id UUID,
    prompt TEXT,
    question_type VARCHAR(50),
    options_json JSON,
    marks DECIMAL(6,2),
    position SMALLINT,
    FOREIGN KEY (question_bank_id) REFERENCES QuestionService_question_banks(question_bank_id)
);

CREATE TABLE QuestionService_answer_keys (
    answer_key_id UUID PRIMARY KEY,
    question_id UUID,
    correct_answer JSON,
    version SMALLINT,
    published_at TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES QuestionService_questions(question_id)
);

-- ==========================================
-- 5. Monitoring Settings Management
-- ==========================================
CREATE TABLE SettingsService_exam_security_policies (
    policy_id UUID PRIMARY KEY,
    exam_id UUID, -- Logical API Link to ScheduleService_exams
    require_webcam BOOLEAN,
    require_screen_monitoring BOOLEAN,
    allow_tab_switch BOOLEAN,
    max_tab_switches SMALLINT,
    suspicion_threshold DECIMAL(4,3),
    updated_by_user_id UUID, -- Logical API Link to UserService_user_profiles
    updated_at TIMESTAMP
);

-- ==========================================
-- 6. Online Examination Service
-- ==========================================
CREATE TABLE ExamService_exam_sessions (
    session_id UUID PRIMARY KEY,
    exam_id UUID, -- Logical API Link to ScheduleService_exams
    student_user_id UUID, -- Logical API Link to UserService_user_profiles
    session_status VARCHAR(50),
    started_at TIMESTAMP,
    expires_at TIMESTAMP,
    submitted_at TIMESTAMP
);

CREATE TABLE ExamService_session_timers (
    timer_id UUID PRIMARY KEY,
    session_id UUID,
    started_at TIMESTAMP,
    duration_seconds INTEGER,
    remaining_seconds INTEGER,
    paused_seconds INTEGER,
    updated_at TIMESTAMP,
    FOREIGN KEY (session_id) REFERENCES ExamService_exam_sessions(session_id)
);

-- ==========================================
-- 7. Answer Submission Service
-- ==========================================
CREATE TABLE AnswerService_submissions (
    submission_id UUID PRIMARY KEY,
    session_id UUID, -- Logical API Link to ExamService_exam_sessions
    student_user_id UUID, -- Logical API Link to UserService_user_profiles
    submission_status VARCHAR(50),
    submitted_at TIMESTAMP,
    is_final BOOLEAN
);

CREATE TABLE AnswerService_submitted_answers (
    answer_id UUID PRIMARY KEY,
    submission_id UUID,
    question_id UUID, -- Logical API Link to QuestionService_questions
    encrypted_payload BYTEA, -- Standard mapped equivalent for BLOB
    saved_at TIMESTAMP,
    answer_version INTEGER,
    FOREIGN KEY (submission_id) REFERENCES AnswerService_submissions(submission_id)
);

-- ==========================================
-- 8. Monitoring Service
-- ==========================================
CREATE TABLE MonitorService_monitoring_sessions (
    monitoring_session_id UUID PRIMARY KEY,
    exam_session_id UUID, -- Logical API Link to ExamService_exam_sessions
    student_user_id UUID, -- Logical API Link to UserService_user_profiles
    started_at TIMESTAMP,
    ended_at TIMESTAMP,
    monitoring_status VARCHAR(50)
);

CREATE TABLE MonitorService_stream_metadata (
    metadata_id UUID PRIMARY KEY,
    monitoring_session_id UUID,
    stream_type VARCHAR(50),
    source VARCHAR(255),
    codec VARCHAR(50),
    resolution VARCHAR(50),
    metadata JSON,
    FOREIGN KEY (monitoring_session_id) REFERENCES MonitorService_monitoring_sessions(monitoring_session_id)
);

CREATE TABLE MonitorService_connection_logs (
    connection_log_id UUID PRIMARY KEY,
    monitoring_session_id UUID,
    event_type VARCHAR(255),
    occurred_at TIMESTAMP,
    details TEXT,
    severity VARCHAR(50),
    FOREIGN KEY (monitoring_session_id) REFERENCES MonitorService_monitoring_sessions(monitoring_session_id)
);

-- ==========================================
-- 9. Malpractice Detection Service
-- ==========================================
CREATE TABLE DetectionService_suspicious_events (
    event_id UUID PRIMARY KEY,
    monitoring_session_id UUID, -- Logical API Link to MonitorService_monitoring_sessions
    exam_session_id UUID, -- Logical API Link to ExamService_exam_sessions
    event_type VARCHAR(255),
    detected_at TIMESTAMP,
    confidence_score DECIMAL(5,4),
    severity VARCHAR(50),
    description TEXT
);

CREATE TABLE DetectionService_anomaly_logs (
    anomaly_log_id UUID PRIMARY KEY,
    event_id UUID,
    model_version VARCHAR(50),
    anomaly_score DECIMAL(5,4),
    analysis_summary TEXT,
    recorded_at TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES DetectionService_suspicious_events(event_id)
);

-- ==========================================
-- 10. Alert & Evidence Review Service
-- ==========================================
CREATE TABLE AlertService_malpractice_alerts (
    alert_id UUID PRIMARY KEY,
    suspicious_event_id UUID, -- Logical API Link to DetectionService_suspicious_events
    exam_session_id UUID, -- Logical API Link to ExamService_exam_sessions
    severity VARCHAR(50),
    alert_status VARCHAR(50),
    reviewed_by_user_id UUID, -- Logical API Link to UserService_user_profiles
    review_decision VARCHAR(255),
    reviewed_at TIMESTAMP
);

CREATE TABLE AlertService_evidence_snapshots (
    snapshot_id UUID PRIMARY KEY,
    alert_id UUID,
    media_type VARCHAR(50),
    storage_uri VARCHAR(500),
    captured_at TIMESTAMP,
    checksum VARCHAR(128),
    metadata JSON,
    FOREIGN KEY (alert_id) REFERENCES AlertService_malpractice_alerts(alert_id)
);

-- ==========================================
-- 11. Results Management Service
-- ==========================================
CREATE TABLE ResultService_exam_results (
    result_id UUID PRIMARY KEY,
    exam_id UUID, -- Logical API Link to ScheduleService_exams
    student_user_id UUID, -- Logical API Link to UserService_user_profiles
    session_id UUID, -- Logical API Link to ExamService_exam_sessions
    submission_id UUID, -- Logical API Link to AnswerService_submissions
    score DECIMAL(7,2),
    max_score DECIMAL(7,2),
    grade VARCHAR(10),
    result_status VARCHAR(50),
    calculated_at TIMESTAMP,
    published_at TIMESTAMP
);

-- ==========================================
-- 12. Reports & Analytics Service
-- ==========================================
CREATE TABLE ReportService_aggregated_reports (
    report_id UUID PRIMARY KEY,
    exam_id UUID, -- Logical API Link to ScheduleService_exams
    requested_by_user_id UUID, -- Logical API Link to UserService_user_profiles
    report_type VARCHAR(50),
    generated_at TIMESTAMP,
    aggregation_scope VARCHAR(50),
    summary_payload JSON,
    report_status VARCHAR(50)
);

CREATE TABLE ReportService_pdf_exports (
    export_id UUID PRIMARY KEY,
    report_id UUID,
    file_uri VARCHAR(500),
    format VARCHAR(20),
    created_at TIMESTAMP,
    file_size_bytes BIGINT,
    export_status VARCHAR(50),
    FOREIGN KEY (report_id) REFERENCES ReportService_aggregated_reports(report_id)
);